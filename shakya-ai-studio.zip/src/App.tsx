/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useCallback, useEffect, useState } from 'react';
import {
  onAuthStateChanged,
  signOut,
  User,
} from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  onSnapshot,
  serverTimestamp,
  setDoc,
  updateDoc,
} from 'firebase/firestore';
import { Loader2 } from 'lucide-react';
import { auth, db, handleFirestoreError, OperationType } from './firebase';
import { generateStarterAndroidApp } from './data/androidTemplate';
import { t } from './i18n/translations';
import {
  Language,
  SavedAndroidApp,
  StudioView,
  VaultSettings,
} from './types/studio';
import { AuthScreen } from './components/AuthScreen';
import { TopBar } from './components/TopBar';
import { BottomNav } from './components/BottomNav';
import { HomeView } from './components/HomeView';
import { WorkspaceView } from './components/WorkspaceView';
import { BuildTrackerView } from './components/BuildTrackerView';
import { VaultView } from './components/VaultView';
import { CreateAppModal } from './components/CreateAppModal';

const STORAGE_VAULT_PREFIX = 'shakya_vault_v2_';
const STORAGE_APPS_PREFIX = 'shakya_apps_v2_';

const DEFAULT_VAULT: VaultSettings = {
  geminiApiKey: '',
  githubUsername: 'shakya77074',
  githubToken: '',
  zegoAppId: '',
  zegoAppSign: '',
  defaultGoogleServicesJson: '',
  defaultGoogleServicesPackage: '',
  keystoreAlias: 'shakya-upload-key',
  keystorePassword: '',
  keyPassword: '',
  defaultPackagePrefix: 'com.shakya',
  defaultLanguage: 'en',
};

function sanitizeId(raw: string): string {
  return raw.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 128);
}

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);

  const [apps, setApps] = useState<SavedAndroidApp[]>([]);
  const [vault, setVault] = useState<VaultSettings>(DEFAULT_VAULT);
  const [lang, setLang] = useState<Language>('en');
  const [activeView, setActiveView] = useState<StudioView>('home');
  const [activeAppId, setActiveAppId] = useState<string>('');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [editingAppIntegrations, setEditingAppIntegrations] =
    useState<SavedAndroidApp | null>(null);

  // 1. Firebase Auth session listener (auto-persists across restarts)
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (firebaseUser) => {
      setUser(firebaseUser);
      setAuthReady(true);
    });
    return () => unsub();
  }, []);

  // 2. Load per-user local Vault & Apps on user change
  useEffect(() => {
    if (!user) {
      setApps([]);
      setActiveAppId('');
      setVault(DEFAULT_VAULT);
      return;
    }

    try {
      const rawVault = localStorage.getItem(`${STORAGE_VAULT_PREFIX}${user.uid}`);
      if (rawVault) {
        const parsedVault = { ...DEFAULT_VAULT, ...JSON.parse(rawVault) };
        setVault(parsedVault);
        setLang(parsedVault.defaultLanguage || 'en');
      } else {
        setVault(DEFAULT_VAULT);
      }
    } catch {
      setVault(DEFAULT_VAULT);
    }

    try {
      const rawApps = localStorage.getItem(`${STORAGE_APPS_PREFIX}${user.uid}`);
      if (rawApps) {
        const parsedApps = JSON.parse(rawApps) as SavedAndroidApp[];
        if (Array.isArray(parsedApps)) {
          setApps(parsedApps);
          setActiveAppId(parsedApps[0]?.id ?? '');
        }
      } else {
        setApps([]);
        setActiveAppId('');
      }
    } catch {
      setApps([]);
    }
  }, [user]);

  // 3. Persist local apps cache per user
  useEffect(() => {
    if (!user) return;
    try {
      localStorage.setItem(
        `${STORAGE_APPS_PREFIX}${user.uid}`,
        JSON.stringify(apps)
      );
    } catch {
      // Ignore storage quota errors
    }
  }, [apps, user]);

  // 4. Sync verified user profile & apps with Firestore
  useEffect(() => {
    if (!user || !user.emailVerified) return;

    const userDocRef = doc(db, 'users', user.uid);
    getDoc(userDocRef)
      .then((snap) => {
        if (!snap.exists()) {
          return setDoc(userDocRef, {
            uid: user.uid,
            email: user.email || '',
            displayName: user.displayName || '',
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        }
        return updateDoc(userDocRef, {
          email: user.email || '',
          displayName: user.displayName || '',
          updatedAt: serverTimestamp(),
        });
      })
      .catch((err) => {
        console.warn('User profile sync note:', err);
      });

    const appsColRef = collection(db, 'users', user.uid, 'apps');
    const unsubApps = onSnapshot(
      appsColRef,
      (snapshot) => {
        if (snapshot.empty) return;
        const remoteApps: SavedAndroidApp[] = snapshot.docs.map((d) => {
          const data = d.data();
          const rebuiltFiles = generateStarterAndroidApp({
            appName: String(data.name || 'App'),
            appNameHi: String(data.nameHi || data.name || 'App'),
            packageName: String(data.packageName || 'com.shakya.app'),
            versionCode: Number(data.versionCode || 1),
            versionName: String(data.versionName || '1.0.0'),
            description: String(data.description || ''),
            includeFirebase: Boolean(data.includeFirebase),
            includeZegoCloud: Boolean(data.includeZegoCloud),
            zegoAppId: String(data.zegoAppId || ''),
            zegoAppSign: vault.zegoAppSign,
          });
          const mergedFiles = data.mainActivityKotlin
            ? rebuiltFiles.map((f) =>
                f.path.endsWith('MainActivity.kt')
                  ? { ...f, content: String(data.mainActivityKotlin) }
                  : f
              )
            : rebuiltFiles;

          return {
            id: String(data.id || d.id),
            ownerId: String(data.ownerId || user.uid),
            name: String(data.name || ''),
            nameHi: String(data.nameHi || data.name || ''),
            packageName: String(data.packageName || ''),
            repoOwner: String(data.repoOwner || vault.githubUsername || 'shakya77074'),
            repoName: String(data.repoName || ''),
            versionName: String(data.versionName || '1.0.0'),
            versionCode: Number(data.versionCode || 1),
            lastUpdated: new Date().toISOString().slice(0, 16).replace('T', ' '),
            description: String(data.description || ''),
            descriptionHi: String(data.descriptionHi || data.description || ''),
            includeFirebase: Boolean(data.includeFirebase),
            includeZegoCloud: Boolean(data.includeZegoCloud),
            zegoAppId: data.zegoAppId ? String(data.zegoAppId) : undefined,
            googleServicesPackage: data.googleServicesPackage
              ? String(data.googleServicesPackage)
              : undefined,
            isGithubSynced: Boolean(data.isGithubSynced),
            lastCommitSha: data.lastCommitSha ? String(data.lastCommitSha) : undefined,
            previewSpec: data.previewSpec || {
              appTitleEn: String(data.name || 'App'),
              appTitleHi: String(data.nameHi || data.name || 'App'),
              primaryColor: '#1877F2',
              showFromShakyaFooter: true,
              tabs: [],
            },
            files: mergedFiles,
            chatHistory: [],
          };
        });

        setApps((localApps) => {
          const byId = new Map(localApps.map((a) => [a.id, a]));
          for (const remote of remoteApps) {
            const existingLocal = byId.get(remote.id);
            byId.set(remote.id, {
              ...remote,
              googleServicesJson: existingLocal?.googleServicesJson,
              zegoAppSign: existingLocal?.zegoAppSign ?? vault.zegoAppSign,
              chatHistory: existingLocal?.chatHistory ?? [],
            });
          }
          return Array.from(byId.values());
        });
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, `users/${user.uid}/apps`);
      }
    );

    return () => unsubApps();
  }, [user, vault.githubUsername, vault.zegoAppSign]);

  const persistAppToFirestore = useCallback(
    async (appObj: SavedAndroidApp, isNew: boolean) => {
      if (!user || !user.emailVerified) return;
      const appId = sanitizeId(appObj.id);
      const appPath = `users/${user.uid}/apps/${appId}`;
      const appRef = doc(db, 'users', user.uid, 'apps', appId);
      const mainAct = appObj.files.find((f) => f.path.endsWith('MainActivity.kt'));

      const payload: Record<string, unknown> = {
        id: appId,
        ownerId: user.uid,
        name: appObj.name.slice(0, 100),
        nameHi: appObj.nameHi.slice(0, 100),
        packageName: appObj.packageName.slice(0, 120),
        repoOwner: appObj.repoOwner.slice(0, 80),
        repoName: appObj.repoName.slice(0, 100),
        versionName: appObj.versionName.slice(0, 32),
        versionCode: appObj.versionCode,
        description: appObj.description.slice(0, 1000),
        descriptionHi: appObj.descriptionHi.slice(0, 1000),
        includeFirebase: appObj.includeFirebase,
        includeZegoCloud: appObj.includeZegoCloud,
        isGithubSynced: appObj.isGithubSynced,
        previewSpec: appObj.previewSpec,
        updatedAt: serverTimestamp(),
      };

      if (appObj.zegoAppId) payload.zegoAppId = appObj.zegoAppId.slice(0, 64);
      if (appObj.googleServicesPackage) {
        payload.googleServicesPackage = appObj.googleServicesPackage.slice(0, 120);
      }
      if (appObj.lastCommitSha) {
        payload.lastCommitSha = appObj.lastCommitSha.slice(0, 64);
      }
      if (mainAct?.content) {
        payload.mainActivityKotlin = mainAct.content.slice(0, 60000);
      }

      try {
        if (isNew) {
          await setDoc(appRef, { ...payload, createdAt: serverTimestamp() });
        } else {
          const updatePayload = { ...payload };
          delete updatePayload.id;
          delete updatePayload.ownerId;
          delete updatePayload.packageName;
          delete updatePayload.repoOwner;
          delete updatePayload.repoName;
          await updateDoc(appRef, updatePayload);
        }
      } catch (err) {
        handleFirestoreError(
          err,
          isNew ? OperationType.CREATE : OperationType.UPDATE,
          appPath
        );
      }
    },
    [user]
  );

  const handleSaveVault = (next: VaultSettings) => {
    setVault(next);
    if (user) {
      try {
        localStorage.setItem(
          `${STORAGE_VAULT_PREFIX}${user.uid}`,
          JSON.stringify(next)
        );
      } catch {
        // Ignore storage errors
      }
    }
  };

  const handleToggleLang = () => {
    const nextLang: Language = lang === 'en' ? 'hi' : 'en';
    setLang(nextLang);
    handleSaveVault({ ...vault, defaultLanguage: nextLang });
  };

  const handleCreateApp = (form: {
    appName: string;
    packageName: string;
    repoName: string;
    description: string;
    includeFirebase: boolean;
    includeZegoCloud: boolean;
    googleServicesJson?: string;
    googleServicesPackage?: string;
  }) => {
    if (!user) return;
    const newId = `app-${Date.now()}`;
    const nowStr = new Date().toISOString().slice(0, 16).replace('T', ' ');
    const zegoId = form.includeZegoCloud ? vault.zegoAppId : '';
    const zegoSign = form.includeZegoCloud ? vault.zegoAppSign : '';

    const files = generateStarterAndroidApp({
      appName: form.appName,
      appNameHi: form.appName,
      packageName: form.packageName,
      versionCode: 1,
      versionName: '1.0.0',
      description: form.description,
      includeFirebase: form.includeFirebase,
      includeZegoCloud: form.includeZegoCloud,
      zegoAppId: zegoId,
      zegoAppSign: zegoSign,
      googleServicesJson: form.googleServicesJson,
    });

    const newApp: SavedAndroidApp = {
      id: newId,
      ownerId: user.uid,
      name: form.appName,
      nameHi: form.appName,
      packageName: form.packageName,
      repoOwner: vault.githubUsername.trim() || 'shakya77074',
      repoName: form.repoName,
      versionName: '1.0.0',
      versionCode: 1,
      lastUpdated: nowStr,
      description: form.description,
      descriptionHi: form.description,
      includeFirebase: form.includeFirebase,
      includeZegoCloud: form.includeZegoCloud,
      zegoAppId: zegoId || undefined,
      zegoAppSign: zegoSign || undefined,
      googleServicesJson: form.googleServicesJson,
      googleServicesPackage: form.googleServicesPackage,
      isGithubSynced: false,
      previewSpec: {
        appTitleEn: form.appName,
        appTitleHi: form.appName,
        primaryColor: '#1877F2',
        showFromShakyaFooter: true,
        fabLabelEn: 'Action',
        fabLabelHi: 'एक्शन',
        tabs: [
          {
            id: 'home',
            labelEn: 'Home',
            labelHi: 'होम',
            icon: 'home',
            components: [
              {
                id: 'starter-hero',
                type: 'hero_card',
                titleEn: `${form.appName}`,
                titleHi: `${form.appName}`,
                subtitleEn: form.description,
                subtitleHi: form.description,
                accent: 'primary',
              },
              {
                id: 'starter-btn',
                type: 'action_button',
                titleEn: 'Test Interactive Action',
                titleHi: 'बटन टेस्ट करें',
                actionType: 'increment_counter',
                accent: 'primary',
              },
            ],
          },
          {
            id: 'settings',
            labelEn: 'Settings',
            labelHi: 'सेटिंग्स',
            icon: 'settings',
            components: [
              {
                id: 'toggle-hi',
                type: 'toggle_row',
                titleEn: 'Hindi Localization (हिंदी)',
                titleHi: 'हिंदी भाषा',
                subtitleEn: 'Switch app interface language',
                subtitleHi: 'भाषा बदलें',
                actionType: 'toggle_state',
              },
            ],
          },
        ],
      },
      files,
      chatHistory: [
        {
          id: `init-${Date.now()}`,
          role: 'assistant',
          text: `Created ${form.appName} (${form.packageName})${form.includeFirebase ? ' with Firebase Auth & Firestore' : ''}${form.includeZegoCloud ? ' and ZegoCloud Calling' : ''}. Describe any UI or feature update below.`,
          timestamp: new Date().toLocaleTimeString([], {
            hour: '2-digit',
            minute: '2-digit',
          }),
        },
      ],
    };

    setApps((prev) => [newApp, ...prev]);
    setActiveAppId(newId);
    setActiveView('studio');
    persistAppToFirestore(newApp, true).catch((err) => {
      console.warn('Cloud save skipped until email verified:', err);
    });
  };

  const handleUpdateApp = (updated: SavedAndroidApp) => {
    setApps((prev) => prev.map((a) => (a.id === updated.id ? updated : a)));
    persistAppToFirestore(updated, false).catch((err) => {
      console.warn('Cloud update note:', err);
    });
  };

  const handleSaveIntegrations = (data: {
    includeFirebase: boolean;
    includeZegoCloud: boolean;
    googleServicesJson?: string;
    googleServicesPackage?: string;
  }) => {
    if (!editingAppIntegrations) return;
    const zegoId = data.includeZegoCloud ? vault.zegoAppId : '';
    const zegoSign = data.includeZegoCloud ? vault.zegoAppSign : '';
    const existingMain = editingAppIntegrations.files.find((f) =>
      f.path.endsWith('MainActivity.kt')
    );

    const regenerated = generateStarterAndroidApp({
      appName: editingAppIntegrations.name,
      appNameHi: editingAppIntegrations.nameHi,
      packageName: editingAppIntegrations.packageName,
      versionCode: editingAppIntegrations.versionCode,
      versionName: editingAppIntegrations.versionName,
      description: editingAppIntegrations.description,
      includeFirebase: data.includeFirebase,
      includeZegoCloud: data.includeZegoCloud,
      zegoAppId: zegoId,
      zegoAppSign: zegoSign,
      googleServicesJson:
        data.googleServicesJson ?? editingAppIntegrations.googleServicesJson,
    }).map((f) =>
      f.path.endsWith('MainActivity.kt') && existingMain
        ? { ...f, content: existingMain.content }
        : f
    );

    handleUpdateApp({
      ...editingAppIntegrations,
      includeFirebase: data.includeFirebase,
      includeZegoCloud: data.includeZegoCloud,
      zegoAppId: zegoId || undefined,
      zegoAppSign: zegoSign || undefined,
      googleServicesJson:
        data.googleServicesJson ?? editingAppIntegrations.googleServicesJson,
      googleServicesPackage:
        data.googleServicesPackage ??
        editingAppIntegrations.googleServicesPackage,
      files: regenerated,
    });
    setEditingAppIntegrations(null);
  };

  const handleLogOut = async () => {
    await signOut(auth);
    setActiveView('home');
  };

  if (!authReady) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <Loader2 className="w-7 h-7 text-[#1877F2] animate-spin" />
      </div>
    );
  }

  if (!user) {
    return <AuthScreen lang={lang} onToggleLang={handleToggleLang} />;
  }

  const activeApp = apps.find((a) => a.id === activeAppId) ?? apps[0] ?? null;

  return (
    <div className="min-h-screen flex flex-col bg-white text-slate-900">
      <TopBar
        lang={lang}
        onToggleLang={handleToggleLang}
        onBrandClick={() => setActiveView('home')}
      />

      <main className="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 pt-6 pb-24">
        {activeView === 'home' && (
          <HomeView
            apps={apps}
            vault={vault}
            lang={lang}
            onOpenApp={(id) => {
              setActiveAppId(id);
              setActiveView('studio');
            }}
            onOpenCreateModal={() => {
              setEditingAppIntegrations(null);
              setIsCreateModalOpen(true);
            }}
            onStartSetup={() => setActiveView('settings')}
          />
        )}

        {activeView === 'studio' && (
          <WorkspaceView
            app={activeApp}
            allApps={apps}
            onSwitchApp={(id) => setActiveAppId(id)}
            onUpdateApp={handleUpdateApp}
            onOpenIntegrations={() => {
              if (activeApp) {
                setEditingAppIntegrations(activeApp);
                setIsCreateModalOpen(true);
              }
            }}
            onOpenSettings={() => setActiveView('settings')}
            onGoHome={() => setActiveView('home')}
            vault={vault}
            lang={lang}
          />
        )}

        {activeView === 'builds' && (
          <BuildTrackerView
            app={activeApp}
            allApps={apps}
            onSwitchApp={(id) => setActiveAppId(id)}
            onUpdateApp={handleUpdateApp}
            onOpenSettings={() => setActiveView('settings')}
            onGoHome={() => setActiveView('home')}
            vault={vault}
            lang={lang}
          />
        )}

        {activeView === 'settings' && (
          <VaultView
            vault={vault}
            userEmail={user.email}
            onSaveVault={handleSaveVault}
            onLogOut={handleLogOut}
            lang={lang}
          />
        )}
      </main>

      <BottomNav
        activeView={activeView}
        onNavigate={setActiveView}
        lang={lang}
      />

      <CreateAppModal
        isOpen={isCreateModalOpen}
        onClose={() => {
          setIsCreateModalOpen(false);
          setEditingAppIntegrations(null);
        }}
        onCreate={handleCreateApp}
        onSaveIntegrations={handleSaveIntegrations}
        editingApp={editingAppIntegrations}
        vault={vault}
        lang={lang}
      />
    </div>
  );
}

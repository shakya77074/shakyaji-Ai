import { AndroidProjectFile } from '../types/studio';

function pkgToPath(packageName: string): string {
  return packageName.replace(/\./g, '/');
}

export function buildWorkflowYaml(appName: string): string {
  return `name: Build APK & Play Store AAB (${appName})

on:
  push:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build:
    name: Build Release APK & AAB
    runs-on: ubuntu-latest

    steps:
      - name: Checkout Repository
        uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'

      - name: Setup Gradle
        uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.10.2'

      - name: Decode Release Keystore (if configured)
        id: keystore
        run: |
          if [ -n "\${{ secrets.ANDROID_KEYSTORE_BASE64 }}" ]; then
            echo "\${{ secrets.ANDROID_KEYSTORE_BASE64 }}" | base64 -d > app/release-keystore.jks
            echo "has_keystore=true" >> $GITHUB_OUTPUT
          else
            echo "has_keystore=false" >> $GITHUB_OUTPUT
          fi

      - name: Build Release APK (assembleRelease)
        env:
          KEYSTORE_PASSWORD: \${{ secrets.KEYSTORE_PASSWORD }}
          KEY_ALIAS: \${{ secrets.KEY_ALIAS }}
          KEY_PASSWORD: \${{ secrets.KEY_PASSWORD }}
        run: gradle assembleRelease --no-daemon --stacktrace

      - name: Build Google Play Store AAB (bundleRelease)
        env:
          KEYSTORE_PASSWORD: \${{ secrets.KEYSTORE_PASSWORD }}
          KEY_ALIAS: \${{ secrets.KEY_ALIAS }}
          KEY_PASSWORD: \${{ secrets.KEY_PASSWORD }}
        run: gradle bundleRelease --no-daemon --stacktrace

      - name: Upload Release APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: app-release-apk
          path: app/build/outputs/apk/release/*.apk
          if-no-files-found: warn

      - name: Upload Play Store AAB Artifact
        uses: actions/upload-artifact@v4
        with:
          name: app-release-aab
          path: app/build/outputs/bundle/release/*.aab
          if-no-files-found: warn
`;
}

export function generateStarterAndroidApp(params: {
  appName: string;
  appNameHi: string;
  packageName: string;
  versionCode: number;
  versionName: string;
  description: string;
  includeFirebase?: boolean;
  includeZegoCloud?: boolean;
  zegoAppId?: string;
  zegoAppSign?: string;
  googleServicesJson?: string;
}): AndroidProjectFile[] {
  const pkgPath = pkgToPath(params.packageName);
  const safeName = params.appName.replace(/"/g, '\\"');
  const safeNameHi = params.appNameHi.replace(/"/g, '\\"');
  const includeFirebase = Boolean(params.includeFirebase);
  const includeZego = Boolean(params.includeZegoCloud);
  const zegoAppId = (params.zegoAppId ?? '').trim();
  const zegoAppSign = (params.zegoAppSign ?? '').trim();

  const files: AndroidProjectFile[] = [
    {
      path: '.github/workflows/build.yml',
      language: 'yaml',
      content: buildWorkflowYaml(params.appName),
    },
    {
      path: 'settings.gradle.kts',
      language: 'gradle',
      content: `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven { url = uri("https://jitpack.io") }
        maven { url = uri("https://storage.zego.im/maven") }
    }
}
rootProject.name = "${safeName}"
include(":app")
`,
    },
    {
      path: 'build.gradle.kts',
      language: 'gradle',
      content: `plugins {
    id("com.android.application") version "8.7.2" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21" apply false
${includeFirebase ? '    id("com.google.gms.google-services") version "4.4.2" apply false\n' : ''}}
`,
    },
    {
      path: 'gradle.properties',
      language: 'properties',
      content: `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
kotlin.code.style=official
android.nonTransitiveRClass=true
`,
    },
    {
      path: 'app/build.gradle.kts',
      language: 'gradle',
      content: `import java.io.File

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
${includeFirebase ? '    id("com.google.gms.google-services")\n' : ''}}

android {
    namespace = "${params.packageName}"
    compileSdk = 35

    defaultConfig {
        applicationId = "${params.packageName}"
        minSdk = 26
        targetSdk = 35
        versionCode = ${params.versionCode}
        versionName = "${params.versionName}"

        vectorDrawables {
            useSupportLibrary = true
        }
    }

    signingConfigs {
        create("release") {
            val keystoreFile = file("release-keystore.jks")
            if (keystoreFile.exists()) {
                storeFile = keystoreFile
                storePassword = System.getenv("KEYSTORE_PASSWORD") ?: ""
                keyAlias = System.getenv("KEY_ALIAS") ?: ""
                keyPassword = System.getenv("KEY_PASSWORD") ?: ""
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            val hasKeystore = File(projectDir, "release-keystore.jks").exists()
            signingConfig = if (hasKeystore) {
                signingConfigs.getByName("release")
            } else {
                signingConfigs.getByName("debug")
            }
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.11.00"))
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
${
  includeFirebase
    ? `
    // Firebase Auth & Firestore (BOM managed)
    implementation(platform("com.google.firebase:firebase-bom:33.6.0"))
    implementation("com.google.firebase:firebase-auth-ktx")
    implementation("com.google.firebase:firebase-firestore-ktx")
`
    : ''
}${
  includeZego
    ? `
    // ZegoCloud Voice & Video Calling Prebuilt UIKit
    implementation("com.github.ZEGOCLOUD:zego_uikit_prebuilt_call_android:+")
`
    : ''
}}
`,
    },
    {
      path: 'app/proguard-rules.pro',
      language: 'text',
      content: `-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
`,
    },
    {
      path: 'app/src/main/AndroidManifest.xml',
      language: 'xml',
      content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-permission android:name="android.permission.INTERNET" />
${
  includeZego
    ? `    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
`
    : ''
}
    <application
        android:allowBackup="true"
        android:label="@string/app_name"
        android:supportsRtl="true"
        android:theme="@style/Theme.Material3.DayNight.NoActionBar">
        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
`,
    },
    {
      path: 'app/src/main/res/values/strings.xml',
      language: 'xml',
      content: `<resources>
    <string name="app_name">${safeName}</string>
    <string name="from_shakya">from SHAKYA</string>
</resources>
`,
    },
    {
      path: 'app/src/main/res/values-hi/strings.xml',
      language: 'xml',
      content: `<resources>
    <string name="app_name">${safeNameHi}</string>
    <string name="from_shakya">from SHAKYA</string>
</resources>
`,
    },
    {
      path: `app/src/main/java/${pkgPath}/ui/theme/Theme.kt`,
      language: 'kotlin',
      content: `package ${params.packageName}.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val RoyalBlue = Color(0xFF1877F2)
val PureWhite = Color(0xFFFFFFFF)
val SoftSurface = Color(0xFFF8FAFC)
val SlateInk = Color(0xFF0F172A)
val SlateMuted = Color(0xFF64748B)
val HairlineBorder = Color(0xFFE2E8F0)

private val ShakyaLightColorScheme = lightColorScheme(
    primary = RoyalBlue,
    onPrimary = PureWhite,
    primaryContainer = Color(0xFFEEF5FF),
    onPrimaryContainer = Color(0xFF0D47A1),
    background = PureWhite,
    onBackground = SlateInk,
    surface = PureWhite,
    onSurface = SlateInk,
    surfaceVariant = SoftSurface,
    onSurfaceVariant = SlateMuted,
    outline = HairlineBorder
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = ShakyaLightColorScheme,
        content = content
    )
}
`,
    },
    {
      path: `app/src/main/java/${pkgPath}/MainActivity.kt`,
      language: 'kotlin',
      content: `package ${params.packageName}

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ${params.packageName}.ui.theme.AppTheme
import ${params.packageName}.ui.theme.HairlineBorder
import ${params.packageName}.ui.theme.RoyalBlue
import ${params.packageName}.ui.theme.SlateMuted

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppTheme {
                MainScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen() {
    var isHindi by remember { mutableStateOf(false) }
    var count by remember { mutableIntStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (isHindi) "${safeNameHi}" else "${safeName}",
                        fontWeight = FontWeight.Bold
                    )
                },
                actions = {
                    TextButton(onClick = { isHindi = !isHindi }) {
                        Icon(Icons.Default.Translate, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (isHindi) "EN" else "हिंदी")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White,
                    titleContentColor = RoyalBlue
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { count++ },
                containerColor = RoyalBlue,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "Action")
            }
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                NavigationBarItem(
                    selected = true,
                    onClick = {},
                    icon = { Icon(Icons.Default.Home, contentDescription = null) },
                    label = { Text(if (isHindi) "होम" else "Home") }
                )
            }
        },
        containerColor = Color.White
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Spacer(Modifier.height(4.dp))
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFFEEF5FF),
                    border = BorderStroke(1.dp, Color(0xFFD6E6FF)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (isHindi) "ऐप तैयार है" else "Jetpack Compose App Ready",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = RoyalBlue
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = "${params.description.replace(/"/g, '\\"')}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = SlateMuted
                        )
                        Spacer(Modifier.height(12.dp))
                        Button(
                            onClick = { count++ },
                            colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue)
                        ) {
                            Text(if (isHindi) "टैप करें ($count)" else "Tap Counter ($count)")
                        }
                    }
                }
            }

            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color.White,
                    border = BorderStroke(1.dp, HairlineBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = if (isHindi) "सक्रिय वर्जन" else "Version",
                                style = MaterialTheme.typography.labelMedium,
                                color = SlateMuted
                            )
                            Text(
                                text = "v${params.versionName} (Build ${params.versionCode})",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Text(
                            text = "from SHAKYA",
                            style = MaterialTheme.typography.labelSmall,
                            color = RoyalBlue,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
`,
    },
  ];

  if (includeFirebase && params.googleServicesJson) {
    files.push({
      path: 'app/google-services.json',
      language: 'json',
      content: params.googleServicesJson,
    });
  }

  if (includeZego) {
    files.push({
      path: `app/src/main/java/${pkgPath}/calling/ZegoCallManager.kt`,
      language: 'kotlin',
      content: `package ${params.packageName}.calling

import android.app.Application
import android.util.Log
import com.zegocloud.uikit.prebuilt.call.ZegoUIKitPrebuiltCallService
import com.zegocloud.uikit.prebuilt.call.invite.ZegoUIKitPrebuiltCallInvitationConfig

/**
 * Crash-safe ZegoCloud Call Manager injected automatically by Shakya AI Studio.
 */
object ZegoCallManager {
    private const val TAG = "ZegoCallManager"
    private const val DEFAULT_APP_ID: Long = ${zegoAppId && /^\d+$/.test(zegoAppId) ? `${zegoAppId}L` : '0L'}
    private const val DEFAULT_APP_SIGN: String = "${zegoAppSign.replace(/"/g, '\\"')}"

    @Volatile
    private var initialized = false

    fun initSafely(
        application: Application,
        userId: String,
        userName: String,
        appId: Long = DEFAULT_APP_ID,
        appSign: String = DEFAULT_APP_SIGN
    ): Boolean {
        if (initialized) return true
        if (appId <= 0L || appSign.isBlank() || userId.isBlank()) {
            Log.w(TAG, "ZegoCloud credentials or userId missing; skipping initialization safely.")
            return false
        }
        return runCatching {
            val config = ZegoUIKitPrebuiltCallInvitationConfig()
            ZegoUIKitPrebuiltCallService.init(
                application,
                appId,
                appSign,
                userId,
                userName.ifBlank { userId },
                config
            )
            initialized = true
            true
        }.onFailure { err ->
            Log.e(TAG, "ZegoCloud initialization failed safely without crash", err)
        }.getOrDefault(false)
    }

    fun uninitSafely() {
        if (!initialized) return
        runCatching {
            ZegoUIKitPrebuiltCallService.unInit()
            initialized = false
        }.onFailure { err ->
            Log.e(TAG, "ZegoCloud unInit error", err)
        }
    }
}
`,
    });
  }

  return files;
}

export function generateShakyaStudioKotlinProject(): AndroidProjectFile[] {
  const pkg = 'com.shakya.aistudio';
  const pkgPath = pkgToPath(pkg);

  return [
    {
      path: '.github/workflows/build.yml',
      language: 'yaml',
      content: buildWorkflowYaml('Shakya AI Studio'),
    },
    {
      path: 'settings.gradle.kts',
      language: 'gradle',
      content: `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven { url = uri("https://jitpack.io") }
    }
}
rootProject.name = "ShakyaAIStudio"
include(":app")
`,
    },
    {
      path: 'build.gradle.kts',
      language: 'gradle',
      content: `plugins {
    id("com.android.application") version "8.7.2" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21" apply false
    id("com.google.devtools.ksp") version "2.0.21-1.0.27" apply false
    id("com.google.gms.google-services") version "4.4.2" apply false
}
`,
    },
    {
      path: 'app/build.gradle.kts',
      language: 'gradle',
      content: `import java.io.File

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
    id("com.google.gms.google-services")
}

android {
    namespace = "com.shakya.aistudio"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.shakya.aistudio"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        vectorDrawables {
            useSupportLibrary = true
        }
    }

    signingConfigs {
        create("release") {
            val keystoreFile = file("release-keystore.jks")
            if (keystoreFile.exists()) {
                storeFile = keystoreFile
                storePassword = System.getenv("KEYSTORE_PASSWORD") ?: ""
                keyAlias = System.getenv("KEY_ALIAS") ?: ""
                keyPassword = System.getenv("KEY_PASSWORD") ?: ""
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            val hasKeystore = File(projectDir, "release-keystore.jks").exists()
            signingConfig = if (hasKeystore) {
                signingConfigs.getByName("release")
            } else {
                signingConfigs.getByName("debug")
            }
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.11.00"))
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    // Firebase Auth + Google Sign-In + Firestore
    implementation(platform("com.google.firebase:firebase-bom:33.6.0"))
    implementation("com.google.firebase:firebase-auth-ktx")
    implementation("com.google.firebase:firebase-firestore-ktx")
    implementation("com.google.android.gms:play-services-auth:21.2.0")

    // DataStore & Room Persistence
    implementation("androidx.datastore:datastore-preferences:1.1.1")
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    // Networking: Retrofit + OkHttp + Gson
    implementation("com.squareup.retrofit2:retrofit:2.11.0")
    implementation("com.squareup.retrofit2:converter-gson:2.11.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}
`,
    },
    {
      path: 'app/src/main/AndroidManifest.xml',
      language: 'xml',
      content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES" />

    <application
        android:allowBackup="true"
        android:label="@string/app_name"
        android:supportsRtl="true"
        android:theme="@style/Theme.Material3.DayNight.NoActionBar">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <provider
            android:name="androidx.core.content.FileProvider"
            android:authorities="\${applicationId}.fileprovider"
            android:exported="false"
            android:grantUriPermissions="true">
            <meta-data
                android:name="android.support.FILE_PROVIDER_PATHS"
                android:resource="@xml/file_paths" />
        </provider>
    </application>
</manifest>
`,
    },
    {
      path: 'app/src/main/res/xml/file_paths.xml',
      language: 'xml',
      content: `<?xml version="1.0" encoding="utf-8"?>
<paths xmlns:android="http://schemas.android.com/apk/res/android">
    <external-path name="public_downloads" path="Download/ShakyaAIStudio/" />
    <files-path name="apk_downloads" path="apks/" />
    <cache-path name="apk_cache" path="apks/" />
</paths>
`,
    },
    {
      path: 'app/src/main/res/values/strings.xml',
      language: 'xml',
      content: `<resources>
    <string name="app_name">Shakya AI Studio</string>
    <string name="from_shakya">from SHAKYA</string>
    <string name="nav_home">Home</string>
    <string name="nav_studio">Studio</string>
    <string name="nav_builds">Builds</string>
    <string name="nav_settings">Settings</string>
</resources>
`,
    },
    {
      path: 'app/src/main/res/values-hi/strings.xml',
      language: 'xml',
      content: `<resources>
    <string name="app_name">शाक्य AI स्टूडियो</string>
    <string name="from_shakya">from SHAKYA</string>
    <string name="nav_home">होम</string>
    <string name="nav_studio">स्टूडियो</string>
    <string name="nav_builds">बिल्ड्स</string>
    <string name="nav_settings">सेटिंग्स</string>
</resources>
`,
    },
    {
      path: `app/src/main/java/${pkgPath}/ui/theme/Theme.kt`,
      language: 'kotlin',
      content: `package com.shakya.aistudio.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val RoyalBlue = Color(0xFF1877F2)
val PureWhite = Color(0xFFFFFFFF)
val SoftCanvas = Color(0xFFF8FAFC)
val InkDark = Color(0xFF0F172A)
val SlateSecondary = Color(0xFF64748B)
val HairlineGray = Color(0xFFE2E8F0)

private val ShakyaColorScheme = lightColorScheme(
    primary = RoyalBlue,
    onPrimary = PureWhite,
    primaryContainer = Color(0xFFEEF5FF),
    onPrimaryContainer = Color(0xFF0C4A9E),
    background = PureWhite,
    onBackground = InkDark,
    surface = PureWhite,
    onSurface = InkDark,
    surfaceVariant = SoftCanvas,
    onSurfaceVariant = SlateSecondary,
    outline = HairlineGray
)

@Composable
fun ShakyaStudioTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = ShakyaColorScheme,
        content = content
    )
}
`,
    },
    {
      path: `app/src/main/java/${pkgPath}/data/VaultStore.kt`,
      language: 'kotlin',
      content: `package com.shakya.aistudio.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.vaultDataStore by preferencesDataStore(name = "shakya_vault_prefs")

data class VaultConfig(
    val geminiApiKey: String = "",
    val githubUsername: String = "shakya77074",
    val githubPat: String = "",
    val zegoAppId: String = "",
    val zegoAppSign: String = "",
    val defaultGoogleServicesJson: String = "",
    val keystoreAlias: String = "",
    val keystorePassword: String = "",
    val keyPassword: String = "",
    val isHindi: Boolean = false
)

class VaultStore(private val context: Context) {
    private object Keys {
        val GEMINI_KEY = stringPreferencesKey("gemini_api_key")
        val GITHUB_USER = stringPreferencesKey("github_username")
        val GITHUB_PAT = stringPreferencesKey("github_pat")
        val ZEGO_APP_ID = stringPreferencesKey("zego_app_id")
        val ZEGO_APP_SIGN = stringPreferencesKey("zego_app_sign")
        val DEFAULT_GOOGLE_JSON = stringPreferencesKey("default_google_services_json")
        val KEYSTORE_ALIAS = stringPreferencesKey("keystore_alias")
        val KEYSTORE_PASS = stringPreferencesKey("keystore_password")
        val KEY_PASS = stringPreferencesKey("key_password")
        val IS_HINDI = booleanPreferencesKey("is_hindi")
    }

    val configFlow: Flow<VaultConfig> = context.vaultDataStore.data.map { prefs ->
        VaultConfig(
            geminiApiKey = prefs[Keys.GEMINI_KEY] ?: "",
            githubUsername = prefs[Keys.GITHUB_USER] ?: "shakya77074",
            githubPat = prefs[Keys.GITHUB_PAT] ?: "",
            zegoAppId = prefs[Keys.ZEGO_APP_ID] ?: "",
            zegoAppSign = prefs[Keys.ZEGO_APP_SIGN] ?: "",
            defaultGoogleServicesJson = prefs[Keys.DEFAULT_GOOGLE_JSON] ?: "",
            keystoreAlias = prefs[Keys.KEYSTORE_ALIAS] ?: "",
            keystorePassword = prefs[Keys.KEYSTORE_PASS] ?: "",
            keyPassword = prefs[Keys.KEY_PASS] ?: "",
            isHindi = prefs[Keys.IS_HINDI] ?: false
        )
    }

    suspend fun saveConfig(config: VaultConfig) {
        context.vaultDataStore.edit { prefs ->
            prefs[Keys.GEMINI_KEY] = config.geminiApiKey
            prefs[Keys.GITHUB_USER] = config.githubUsername
            prefs[Keys.GITHUB_PAT] = config.githubPat
            prefs[Keys.ZEGO_APP_ID] = config.zegoAppId
            prefs[Keys.ZEGO_APP_SIGN] = config.zegoAppSign
            prefs[Keys.DEFAULT_GOOGLE_JSON] = config.defaultGoogleServicesJson
            prefs[Keys.KEYSTORE_ALIAS] = config.keystoreAlias
            prefs[Keys.KEYSTORE_PASS] = config.keystorePassword
            prefs[Keys.KEY_PASS] = config.keyPassword
            prefs[Keys.IS_HINDI] = config.isHindi
        }
    }

    suspend fun toggleLanguage(isHindi: Boolean) {
        context.vaultDataStore.edit { it[Keys.IS_HINDI] = isHindi }
    }
}
`,
    },
    {
      path: `app/src/main/java/${pkgPath}/installer/MobileArtifactDownloader.kt`,
      language: 'kotlin',
      content: `package com.shakya.aistudio.installer

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import androidx.core.content.FileProvider
import java.io.File
import java.io.InputStream
import java.util.zip.ZipInputStream

object MobileArtifactDownloader {

    /**
     * Enqueues a visible system download into Downloads/ShakyaAIStudio/ via Android DownloadManager.
     */
    fun enqueueSystemDownload(
        context: Context,
        downloadUrl: String,
        bearerToken: String,
        fileName: String,
        title: String
    ): Long {
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val request = DownloadManager.Request(Uri.parse(downloadUrl)).apply {
            addRequestHeader("Authorization", "Bearer $bearerToken")
            addRequestHeader("Accept", "application/vnd.github+json")
            setTitle(title)
            setDescription("Saving to Downloads/ShakyaAIStudio/$fileName")
            setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            setDestinationInExternalPublicDir(
                Environment.DIRECTORY_DOWNLOADS,
                "ShakyaAIStudio/$fileName"
            )
        }
        return dm.enqueue(request)
    }

    /**
     * Extracts .apk directly into Downloads/ShakyaAIStudio/ and launches Android package installer via FileProvider.
     */
    fun extractAndInstallApk(context: Context, zipStream: InputStream, fileName: String): Result<File> {
        return runCatching {
            val dir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                "ShakyaAIStudio"
            ).apply { mkdirs() }
            var outApk: File? = null

            ZipInputStream(zipStream).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory && entry.name.endsWith(".apk")) {
                        val target = File(dir, fileName)
                        target.outputStream().use { zis.copyTo(it) }
                        outApk = target
                        break
                    }
                    entry = zis.nextEntry
                }
            }

            val apk = outApk ?: error("No .apk found in build artifact.")
            val uri = FileProvider.getUriForFile(context, "\${context.packageName}.fileprovider", apk)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(intent)
            apk
        }
    }

    /**
     * Extracts .aab bundle directly into Downloads/ShakyaAIStudio/ ready for Play Console upload.
     */
    fun extractAabToDownloads(context: Context, zipStream: InputStream, fileName: String): Result<File> {
        return runCatching {
            val dir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                "ShakyaAIStudio"
            ).apply { mkdirs() }
            var outAab: File? = null

            ZipInputStream(zipStream).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory && entry.name.endsWith(".aab")) {
                        val target = File(dir, fileName)
                        target.outputStream().use { zis.copyTo(it) }
                        outAab = target
                        break
                    }
                    entry = zis.nextEntry
                }
            }
            outAab ?: error("No .aab bundle found in build artifact.")
        }
    }
}
`,
    },
    {
      path: `app/src/main/java/${pkgPath}/MainActivity.kt`,
      language: 'kotlin',
      content: `package com.shakya.aistudio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth
import com.shakya.aistudio.data.VaultConfig
import com.shakya.aistudio.data.VaultStore
import com.shakya.aistudio.ui.theme.HairlineGray
import com.shakya.aistudio.ui.theme.RoyalBlue
import com.shakya.aistudio.ui.theme.ShakyaStudioTheme
import com.shakya.aistudio.ui.theme.SlateSecondary
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ShakyaStudioTheme {
                ShakyaStudioRoot()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShakyaStudioRoot() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val vaultStore = remember { VaultStore(context) }
    val vaultConfig by vaultStore.configFlow.collectAsState(initial = VaultConfig())
    val auth = remember { FirebaseAuth.getInstance() }
    var currentUser by remember { mutableStateOf(auth.currentUser) }

    DisposableEffect(auth) {
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            currentUser = firebaseAuth.currentUser
        }
        auth.addAuthStateListener(listener)
        onDispose { auth.removeAuthStateListener(listener) }
    }

    val isHindi = vaultConfig.isHindi

    if (currentUser == null) {
        AuthGateScreen(
            isHindi = isHindi,
            onToggleLang = { scope.launch { vaultStore.toggleLanguage(!isHindi) } },
            onAuthSuccess = { currentUser = auth.currentUser }
        )
        return
    }

    var selectedTab by remember { mutableIntStateOf(0) }
    var studioMode by remember { mutableIntStateOf(0) } // 0 = AI Chat, 1 = Live Mobile Screen

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (isHindi) "शाक्य AI स्टूडियो" else "Shakya AI Studio",
                        fontWeight = FontWeight.Bold,
                        color = RoyalBlue
                    )
                },
                actions = {
                    TextButton(onClick = { scope.launch { vaultStore.toggleLanguage(!isHindi) } }) {
                        Text(if (isHindi) "English" else "हिंदी", fontWeight = FontWeight.SemiBold, color = RoyalBlue)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Home, contentDescription = null) },
                    label = { Text(if (isHindi) "होम" else "Home") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.AutoAwesome, contentDescription = null) },
                    label = { Text(if (isHindi) "स्टूडियो" else "Studio") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.Download, contentDescription = null) },
                    label = { Text(if (isHindi) "बिल्ड्स" else "Builds") }
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                    label = { Text(if (isHindi) "सेटिंग्स" else "Settings") }
                )
            }
        },
        containerColor = Color.White
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            when (selectedTab) {
                0 -> HomeAppsScreen(
                    config = vaultConfig,
                    isHindi = isHindi,
                    onStartSetup = { selectedTab = 3 },
                    onOpenStudio = { selectedTab = 1 }
                )
                1 -> StudioWorkspaceScreen(
                    isHindi = isHindi,
                    studioMode = studioMode,
                    onModeChange = { studioMode = it }
                )
                2 -> BuildsDownloadScreen(isHindi = isHindi)
                3 -> SettingsVaultScreen(
                    config = vaultConfig,
                    isHindi = isHindi,
                    onSave = { updated -> scope.launch { vaultStore.saveConfig(updated) } },
                    onLogOut = { auth.signOut() }
                )
            }
        }
    }
}

@Composable
fun AuthGateScreen(
    isHindi: Boolean,
    onToggleLang: () -> Unit,
    onAuthSuccess: () -> Unit
) {
    val auth = remember { FirebaseAuth.getInstance() }
    val context = LocalContext.current
    var errorText by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (isHindi) "शाक्य AI स्टूडियो" else "Shakya AI Studio",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = RoyalBlue
            )
            TextButton(onClick = onToggleLang) {
                Text(if (isHindi) "English" else "हिंदी", color = RoyalBlue)
            }
        }

        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = if (isHindi) "शाक्य AI स्टूडियो में स्वागत है" else "Welcome to Shakya AI Studio",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = if (isHindi) {
                    "अपने Google अकाउंट से साइन इन करें"
                } else {
                    "Sign in with your Google account to continue"
                },
                color = SlateSecondary,
                style = MaterialTheme.typography.bodyMedium
            )
            errorText?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Button(
                onClick = {
                    val activity = context as? android.app.Activity
                    if (activity == null) {
                        errorText = "Activity unavailable for Google Sign-In"
                        return@Button
                    }
                    val provider = com.google.firebase.auth.OAuthProvider.newBuilder("google.com").build()
                    auth.startActivityForSignInWithProvider(activity, provider)
                        .addOnSuccessListener { onAuthSuccess() }
                        .addOnFailureListener { errorText = it.localizedMessage }
                },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue)
            ) {
                Text("Continue with Google", fontWeight = FontWeight.SemiBold)
            }
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = if (isHindi) {
                    "अस्वीकरण: Shakya AI Studio के माध्यम से बनाए गए ऐप्स और कंटेंट के लिए यूज़र स्वयं ज़िम्मेदार होंगे।"
                } else {
                    "Disclaimer: Users are solely responsible for the apps and content they create using Shakya AI Studio."
                },
                color = SlateSecondary,
                style = MaterialTheme.typography.bodySmall
            )
            Text("from SHAKYA", color = SlateSecondary, style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable
fun HomeAppsScreen(
    config: VaultConfig,
    isHindi: Boolean,
    onStartSetup: () -> Unit,
    onOpenStudio: () -> Unit
) {
    val needsSetup = config.geminiApiKey.isBlank() || config.githubPat.isBlank()
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (needsSetup) {
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFFEEF5FF),
                    border = BorderStroke(1.dp, Color(0xFFD4E4FF)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("1. Add API Keys in Settings", fontWeight = FontWeight.Medium)
                        Text("2. Tap + Create New App", fontWeight = FontWeight.Medium)
                        Text("3. Build & Download APK/AAB", fontWeight = FontWeight.Medium)
                        Spacer(Modifier.height(6.dp))
                        Button(
                            onClick = onStartSetup,
                            colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue)
                        ) {
                            Text(if (isHindi) "सेटअप शुरू करें" else "Start Setup")
                        }
                    }
                }
            }
        }
        item {
            Button(
                onClick = onOpenStudio,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue)
            ) {
                Text(if (isHindi) "+ नया ऐप बनाएं" else "+ Create New App")
            }
        }
        item {
            Box(modifier = Modifier.fillMaxWidth().padding(top = 24.dp), contentAlignment = Alignment.Center) {
                Text("from SHAKYA", color = SlateSecondary, style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

@Composable
fun StudioWorkspaceScreen(isHindi: Boolean, studioMode: Int, onModeChange: (Int) -> Unit) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        TabRow(selectedTabIndex = studioMode, containerColor = Color.White, contentColor = RoyalBlue) {
            Tab(selected = studioMode == 0, onClick = { onModeChange(0) }, text = { Text(if (isHindi) "AI चैट" else "AI Chat") })
            Tab(selected = studioMode == 1, onClick = { onModeChange(1) }, text = { Text(if (isHindi) "लाइव मोबाइल स्क्रीन" else "Live Mobile Screen") })
        }
        Spacer(Modifier.height(16.dp))
        Text(
            text = if (studioMode == 0) "AI Chat Builder Ready" else "Interactive Live Mobile Screen Preview",
            style = MaterialTheme.typography.titleMedium
        )
    }
}

@Composable
fun BuildsDownloadScreen(isHindi: Boolean) {
    Column(modifier = Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(if (isHindi) "APK और Play Store AAB बिल्ड्स" else "Builds", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Button(onClick = {}, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue)) {
            Text(if (isHindi) "APK डाउनलोड और इंस्टॉल करें" else "Download & Install APK")
        }
        OutlinedButton(onClick = {}, modifier = Modifier.fillMaxWidth()) {
            Text(if (isHindi) "App Bundle (.aab) डाउनलोड करें" else "Download App Bundle (.aab)")
        }
    }
}

@Composable
fun SettingsVaultScreen(
    config: VaultConfig,
    isHindi: Boolean,
    onSave: (VaultConfig) -> Unit,
    onLogOut: () -> Unit
) {
    var gemini by remember(config) { mutableStateOf(config.geminiApiKey) }
    var githubUser by remember(config) { mutableStateOf(config.githubUsername) }
    var githubPat by remember(config) { mutableStateOf(config.githubPat) }
    var zegoId by remember(config) { mutableStateOf(config.zegoAppId) }
    var zegoSign by remember(config) { mutableStateOf(config.zegoAppSign) }

    LazyColumn(modifier = Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { OutlinedTextField(value = gemini, onValueChange = { gemini = it }, label = { Text("Gemini API Key") }, modifier = Modifier.fillMaxWidth()) }
        item { OutlinedTextField(value = githubUser, onValueChange = { githubUser = it }, label = { Text("GitHub Username") }, modifier = Modifier.fillMaxWidth()) }
        item { OutlinedTextField(value = githubPat, onValueChange = { githubPat = it }, label = { Text("GitHub PAT") }, modifier = Modifier.fillMaxWidth()) }
        item { OutlinedTextField(value = zegoId, onValueChange = { zegoId = it }, label = { Text("ZEGO_APP_ID") }, modifier = Modifier.fillMaxWidth()) }
        item { OutlinedTextField(value = zegoSign, onValueChange = { zegoSign = it }, label = { Text("ZEGO_APP_SIGN") }, modifier = Modifier.fillMaxWidth()) }
        item {
            Button(
                onClick = { onSave(config.copy(geminiApiKey = gemini, githubUsername = githubUser, githubPat = githubPat, zegoAppId = zegoId, zegoAppSign = zegoSign)) },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue)
            ) {
                Text(if (isHindi) "सेटिंग्स सहेजें" else "Save Settings")
            }
        }
        item {
            OutlinedButton(onClick = onLogOut, modifier = Modifier.fillMaxWidth()) {
                Text(if (isHindi) "लॉग आउट करें" else "Log Out")
            }
        }
    }
}
`,
    },
  ];
}

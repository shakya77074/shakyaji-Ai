export type Language = 'en' | 'hi';

export type StudioView = 'home' | 'studio' | 'builds' | 'settings';

export interface AndroidProjectFile {
  path: string;
  content: string;
  language: 'kotlin' | 'gradle' | 'xml' | 'yaml' | 'properties' | 'json' | 'text';
}

export type PreviewComponentType =
  | 'hero_card'
  | 'stat_row'
  | 'action_button'
  | 'toggle_row'
  | 'input_field'
  | 'list_item'
  | 'section_title'
  | 'info_banner';

export interface PreviewComponent {
  id: string;
  type: PreviewComponentType;
  titleEn: string;
  titleHi: string;
  subtitleEn?: string;
  subtitleHi?: string;
  value?: string;
  actionType?: 'increment_counter' | 'toggle_state' | 'show_snackbar' | 'switch_tab' | 'submit_form';
  actionTarget?: string;
  accent?: 'primary' | 'emerald' | 'amber' | 'neutral';
  icon?: string;
}

export interface PreviewTab {
  id: string;
  labelEn: string;
  labelHi: string;
  icon: 'home' | 'list' | 'add' | 'chart' | 'settings' | 'wallet';
  components: PreviewComponent[];
}

export interface ComposePreviewSpec {
  appTitleEn: string;
  appTitleHi: string;
  primaryColor: string;
  showFromShakyaFooter: boolean;
  fabLabelEn?: string;
  fabLabelHi?: string;
  tabs: PreviewTab[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  timestamp: string;
  updatedFiles?: string[];
}

export interface SavedAndroidApp {
  id: string;
  ownerId: string;
  name: string;
  nameHi: string;
  packageName: string;
  repoOwner: string;
  repoName: string;
  versionName: string;
  versionCode: number;
  lastUpdated: string;
  description: string;
  descriptionHi: string;
  includeFirebase: boolean;
  includeZegoCloud: boolean;
  zegoAppId?: string;
  zegoAppSign?: string;
  googleServicesJson?: string;
  googleServicesPackage?: string;
  isGithubSynced: boolean;
  lastCommitSha?: string;
  previewSpec: ComposePreviewSpec;
  files: AndroidProjectFile[];
  chatHistory: ChatMessage[];
}

export interface GitHubUserProfile {
  login: string;
  name: string | null;
  avatar_url: string;
  public_repos: number;
  html_url: string;
}

export interface GitHubJobStep {
  name: string;
  status: string;
  conclusion: string | null;
  number: number;
}

export interface GitHubBuildRun {
  id: number;
  name: string;
  status: 'queued' | 'in_progress' | 'completed' | string;
  conclusion: 'success' | 'failure' | 'cancelled' | null | string;
  head_sha: string;
  head_commit?: {
    message?: string;
  };
  created_at: string;
  updated_at: string;
  html_url: string;
  run_number: number;
  steps?: GitHubJobStep[];
}

export interface GitHubArtifact {
  id: number;
  name: string;
  size_in_bytes: number;
  archive_download_url: string;
  expired: boolean;
  created_at: string;
  kind: 'apk' | 'aab' | 'other';
}

export interface VaultSettings {
  geminiApiKey: string;
  githubUsername: string;
  githubToken: string;
  zegoAppId: string;
  zegoAppSign: string;
  defaultGoogleServicesJson: string;
  defaultGoogleServicesPackage: string;
  keystoreAlias: string;
  keystorePassword: string;
  keyPassword: string;
  defaultPackagePrefix: string;
  defaultLanguage: Language;
}

import React, { useState } from 'react';
import {
  BarChart3,
  CheckCircle2,
  ChevronRight,
  Home,
  Languages,
  ListChecks,
  Plus,
  Settings,
  Wallet,
  Wifi,
  BatteryCharging,
} from 'lucide-react';
import { ComposePreviewSpec, Language, PreviewComponent } from '../types/studio';
import { t } from '../i18n/translations';

interface PhonePreviewProps {
  spec: ComposePreviewSpec;
  studioLang: Language;
  versionName: string;
  versionCode: number;
}

export const PhonePreview: React.FC<PhonePreviewProps> = ({
  spec,
  studioLang,
  versionName,
  versionCode,
}) => {
  const [phoneLang, setPhoneLang] = useState<Language>(studioLang);
  const [activeTabIdx, setActiveTabIdx] = useState(0);
  const [counter, setCounter] = useState(0);
  const [toggles, setToggles] = useState<Record<string, boolean>>({});
  const [inputs, setInputs] = useState<Record<string, string>>({});
  const [snackbar, setSnackbar] = useState<string | null>(null);

  const tabs = spec.tabs.length > 0 ? spec.tabs : [];
  const safeTabIdx = activeTabIdx < tabs.length ? activeTabIdx : 0;
  const activeTab = tabs[safeTabIdx];

  const triggerFeedback = (msg: string) => {
    setSnackbar(msg);
    setTimeout(() => {
      setSnackbar((curr) => (curr === msg ? null : curr));
    }, 2400);
  };

  const handleAction = (comp: PreviewComponent) => {
    const title = phoneLang === 'hi' ? comp.titleHi : comp.titleEn;
    if (comp.actionType === 'increment_counter') {
      const next = counter + 1;
      setCounter(next);
      triggerFeedback(`${title} · #${next}`);
    } else if (comp.actionType === 'toggle_state') {
      setToggles((prev) => ({ ...prev, [comp.id]: !prev[comp.id] }));
    } else {
      triggerFeedback(title);
    }
  };

  const renderTabIcon = (iconName: string, active: boolean) => {
    const cls = `w-5 h-5 ${active ? 'text-[#1877F2]' : 'text-slate-500'}`;
    switch (iconName) {
      case 'chart':
        return <BarChart3 className={cls} />;
      case 'settings':
        return <Settings className={cls} />;
      case 'wallet':
        return <Wallet className={cls} />;
      case 'list':
        return <ListChecks className={cls} />;
      default:
        return <Home className={cls} />;
    }
  };

  const renderComponent = (comp: PreviewComponent) => {
    const title = phoneLang === 'hi' ? comp.titleHi : comp.titleEn;
    const subtitle = phoneLang === 'hi' ? comp.subtitleHi : comp.subtitleEn;

    switch (comp.type) {
      case 'hero_card':
        return (
          <div
            key={comp.id}
            onClick={() => handleAction(comp)}
            className="p-4 rounded-2xl bg-[#EEF5FF] border border-[#D4E4FF] cursor-pointer active:scale-[0.99] transition-transform"
          >
            <div className="text-sm font-display font-bold text-[#1877F2]">
              {title}
            </div>
            {subtitle && (
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                {subtitle}
              </p>
            )}
          </div>
        );

      case 'stat_row':
        return (
          <div
            key={comp.id}
            className="p-3.5 rounded-2xl bg-white border border-slate-200 flex items-center justify-between gap-3"
          >
            <div>
              <div className="text-[11px] font-medium text-slate-500">
                {title}
              </div>
              {subtitle && (
                <div className="text-[11px] text-slate-400 mt-0.5">
                  {subtitle}
                </div>
              )}
            </div>
            <div className="text-xl font-display font-bold text-[#1877F2] tabular-nums">
              {comp.value ?? String(counter)}
            </div>
          </div>
        );

      case 'action_button': {
        const isEmerald = comp.accent === 'emerald';
        return (
          <button
            key={comp.id}
            type="button"
            onClick={() => handleAction(comp)}
            className={`w-full py-3 px-4 rounded-xl text-xs font-semibold text-white transition-transform active:scale-[0.98] cursor-pointer flex items-center justify-center gap-2 ${
              isEmerald
                ? 'bg-emerald-600 hover:bg-emerald-700'
                : 'bg-[#1877F2] hover:bg-[#1565D8]'
            }`}
          >
            <span>{title}</span>
            {comp.actionType === 'increment_counter' && counter > 0 && (
              <span className="font-mono tabular-nums">({counter})</span>
            )}
          </button>
        );
      }

      case 'toggle_row': {
        const checked = Boolean(toggles[comp.id]);
        return (
          <div
            key={comp.id}
            onClick={() => {
              const next = !checked;
              setToggles((p) => ({ ...p, [comp.id]: next }));
              if (comp.id === 'toggle-hi') {
                setPhoneLang(next ? 'hi' : 'en');
              }
            }}
            className="p-3.5 rounded-2xl bg-white border border-slate-200 flex items-center justify-between gap-3 cursor-pointer"
          >
            <div className="min-w-0">
              <div className="text-xs font-semibold text-slate-800 truncate">
                {title}
              </div>
              {subtitle && (
                <div className="text-[11px] text-slate-500 truncate mt-0.5">
                  {subtitle}
                </div>
              )}
            </div>
            <div
              className={`w-10 h-6 rounded-full p-0.5 transition-colors shrink-0 ${
                checked ? 'bg-[#1877F2]' : 'bg-slate-200'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${
                  checked ? 'translate-x-4' : 'translate-x-0'
                }`}
              />
            </div>
          </div>
        );
      }

      case 'input_field':
        return (
          <div
            key={comp.id}
            className="p-3 rounded-2xl bg-white border border-slate-200"
          >
            <label className="block text-[11px] font-medium text-slate-500 mb-1">
              {title}
            </label>
            <input
              type="text"
              value={inputs[comp.id] ?? comp.value ?? ''}
              onChange={(e) =>
                setInputs((prev) => ({ ...prev, [comp.id]: e.target.value }))
              }
              className="w-full text-xs font-medium text-slate-900 bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-2 focus:outline-none focus:border-[#1877F2]"
            />
          </div>
        );

      case 'info_banner':
        return (
          <div
            key={comp.id}
            className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200"
          >
            <div className="text-xs font-semibold text-slate-800">{title}</div>
            {subtitle && (
              <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                {subtitle}
              </p>
            )}
          </div>
        );

      case 'section_title':
        return (
          <div
            key={comp.id}
            className="text-xs font-semibold text-slate-500 pt-1"
          >
            {title}
          </div>
        );

      case 'list_item':
      default:
        return (
          <button
            key={comp.id}
            type="button"
            onClick={() => handleAction(comp)}
            className="w-full text-left p-3.5 rounded-2xl bg-white border border-slate-200 hover:border-[#1877F2]/40 transition-colors flex items-center justify-between gap-2 cursor-pointer"
          >
            <div className="min-w-0">
              <div className="text-xs font-semibold text-slate-900 truncate">
                {title}
              </div>
              {subtitle && (
                <div className="text-[11px] text-slate-500 truncate mt-0.5">
                  {subtitle}
                </div>
              )}
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
          </button>
        );
    }
  };

  return (
    <div className="flex flex-col items-center">
      {/* Phone Bezel */}
      <div className="w-[332px] h-[660px] rounded-[42px] bg-slate-900 p-3 shadow-xl border border-slate-800 flex flex-col">
        {/* Inner Android Screen */}
        <div className="relative flex-1 bg-white rounded-[32px] overflow-hidden flex flex-col border border-slate-200">
          {/* Android Status Bar */}
          <div className="px-5 pt-2.5 pb-1.5 flex items-center justify-between text-[11px] font-medium text-slate-800 bg-white">
            <span className="tabular-nums font-semibold">14:20</span>
            {/* Camera Punch Hole */}
            <div className="w-3 h-3 rounded-full bg-slate-900" />
            <div className="flex items-center gap-1.5 text-slate-700">
              <Wifi className="w-3.5 h-3.5" />
              <BatteryCharging className="w-3.5 h-3.5" />
            </div>
          </div>

          {/* Material 3 TopAppBar */}
          <div className="px-4 py-2.5 border-b border-slate-100 flex items-center justify-between gap-2 bg-white">
            <div className="min-w-0">
              <div className="text-sm font-display font-bold text-[#1877F2] truncate">
                {phoneLang === 'hi' ? spec.appTitleHi : spec.appTitleEn}
              </div>
              <div className="text-[10px] font-mono text-slate-400 tabular-nums">
                v{versionName} · Build {versionCode}
              </div>
            </div>
            <button
              type="button"
              onClick={() => setPhoneLang((l) => (l === 'en' ? 'hi' : 'en'))}
              className="inline-flex items-center gap-1 px-2 py-1 rounded-lg text-[11px] font-semibold text-[#1877F2] bg-[#EEF5FF] hover:bg-[#dcebff] cursor-pointer shrink-0"
              title="Toggle Hindi / English inside preview"
            >
              <Languages className="w-3.5 h-3.5" />
              <span>{phoneLang === 'hi' ? 'EN' : 'हिंदी'}</span>
            </button>
          </div>

          {/* Scrollable Compose Body */}
          <div className="flex-1 overflow-y-auto p-3.5 space-y-2.5 bg-slate-50/50">
            {activeTab?.components.map(renderComponent)}

            {spec.showFromShakyaFooter && (
              <div className="pt-3 pb-2 text-center text-[10px] font-semibold tracking-wide text-[#1877F2]/80">
                from SHAKYA
              </div>
            )}
          </div>

          {/* Material 3 Floating Action Button */}
          {spec.fabLabelEn && (
            <button
              type="button"
              onClick={() => {
                setCounter((c) => c + 1);
                triggerFeedback(
                  phoneLang === 'hi'
                    ? spec.fabLabelHi || 'जोड़ा गया'
                    : spec.fabLabelEn || 'Added'
                );
              }}
              className="absolute right-4 bottom-[74px] h-11 px-3.5 rounded-2xl bg-[#1877F2] text-white shadow-lg shadow-[#1877F2]/30 flex items-center gap-1.5 text-xs font-semibold active:scale-95 transition-transform cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>{phoneLang === 'hi' ? spec.fabLabelHi : spec.fabLabelEn}</span>
            </button>
          )}

          {/* Live Snackbar */}
          {snackbar && (
            <div className="absolute left-3 right-3 bottom-[72px] bg-slate-900 text-white text-[11px] px-3 py-2 rounded-xl shadow-lg flex items-center gap-2 z-20">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span className="truncate">{snackbar}</span>
            </div>
          )}

          {/* Material 3 NavigationBar */}
          {tabs.length > 0 && (
            <div className="h-16 border-t border-slate-200 bg-white grid grid-flow-col auto-cols-fr items-center px-2">
              {tabs.map((tab, idx) => {
                const active = idx === safeTabIdx;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setActiveTabIdx(idx)}
                    className="flex flex-col items-center justify-center gap-1 py-1.5 cursor-pointer"
                  >
                    <div
                      className={`px-3 py-1 rounded-full transition-colors ${
                        active ? 'bg-[#EEF5FF]' : ''
                      }`}
                    >
                      {renderTabIcon(tab.icon, active)}
                    </div>
                    <span
                      className={`text-[10px] font-medium truncate max-w-[72px] ${
                        active ? 'text-[#1877F2] font-semibold' : 'text-slate-500'
                      }`}
                    >
                      {phoneLang === 'hi' ? tab.labelHi : tab.labelEn}
                    </span>
                  </button>
                );
              })}
            </div>
          )}

          {/* Gesture Pill */}
          <div className="h-3.5 bg-white flex items-center justify-center">
            <div className="w-24 h-1 rounded-full bg-slate-300" />
          </div>
        </div>
      </div>

      <p className="text-xs text-slate-500 mt-3 text-center max-w-[300px]">
        {t(studioLang, 'tapTestHint')}
      </p>
    </div>
  );
};

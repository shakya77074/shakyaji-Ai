import React, { useCallback, useEffect, useState } from 'react';
import {
  CheckCircle2,
  Clock,
  Download,
  ExternalLink,
  GitCommitHorizontal,
  Home,
  Loader2,
  PackageCheck,
  RefreshCw,
  Smartphone,
  XCircle,
} from 'lucide-react';
import {
  GitHubArtifact,
  GitHubBuildRun,
  GitHubJobStep,
  Language,
  SavedAndroidApp,
  VaultSettings,
} from '../types/studio';
import { t } from '../i18n/translations';

interface BuildTrackerViewProps {
  app: SavedAndroidApp | null;
  allApps: SavedAndroidApp[];
  onSwitchApp: (appId: string) => void;
  onUpdateApp: (updated: SavedAndroidApp) => void;
  onOpenSettings: () => void;
  onGoHome: () => void;
  vault: VaultSettings;
  lang: Language;
}

export const BuildTrackerView: React.FC<BuildTrackerViewProps> = ({
  app,
  allApps,
  onSwitchApp,
  onUpdateApp,
  onOpenSettings,
  onGoHome,
  vault,
  lang,
}) => {
  const [runs, setRuns] = useState<GitHubBuildRun[]>([]);
  const [steps, setSteps] = useState<GitHubJobStep[]>([]);
  const [artifacts, setArtifacts] = useState<GitHubArtifact[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isPushing, setIsPushing] = useState(false);
  const [downloadingKind, setDownloadingKind] = useState<'apk' | 'aab' | null>(
    null
  );
  const [autoPoll, setAutoPoll] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const owner = vault.githubUsername.trim() || app?.repoOwner || 'shakya77074';
  const repoName = app?.repoName || '';

  const fetchRuns = useCallback(async () => {
    if (!app || !vault.githubToken.trim()) {
      setRuns([]);
      setSteps([]);
      setArtifacts([]);
      return;
    }

    setIsLoading(true);
    setErrorMsg(null);
    try {
      const res = await fetch('/api/github/runs', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-github-token': vault.githubToken.trim(),
        },
        body: JSON.stringify({ owner, repo: repoName }),
      });
      const data = await res.json();
      if (!res.ok) {
        if (res.status === 404) {
          setRuns([]);
          setSteps([]);
          setArtifacts([]);
          return;
        }
        throw new Error(data.error || 'Could not fetch GitHub Actions status.');
      }
      setRuns(data.runs ?? []);
      setSteps(data.latestSteps ?? []);
      setArtifacts(data.artifacts ?? []);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Polling failed.');
    } finally {
      setIsLoading(false);
    }
  }, [app, owner, repoName, vault.githubToken]);

  useEffect(() => {
    fetchRuns();
  }, [fetchRuns]);

  useEffect(() => {
    if (!app || !autoPoll || !vault.githubToken.trim()) return;
    const latest = runs[0];
    const shouldPoll = !latest || latest.status !== 'completed';
    if (!shouldPoll) return;

    const timer = setInterval(fetchRuns, 6000);
    return () => clearInterval(timer);
  }, [app, autoPoll, fetchRuns, runs, vault.githubToken]);

  if (!app) {
    return (
      <section className="max-w-xl mx-auto py-16 text-center space-y-4">
        <div className="w-12 h-12 rounded-2xl bg-[#EEF5FF] text-[#1877F2] flex items-center justify-center mx-auto">
          <Download className="w-6 h-6" />
        </div>
        <h2 className="text-xl font-display font-bold text-slate-900">
          {t(lang, 'studioEmptyTitle')}
        </h2>
        <p className="text-sm text-slate-500">{t(lang, 'studioEmptyDesc')}</p>
        <button
          type="button"
          onClick={onGoHome}
          className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-[#1877F2] hover:bg-[#1565D8] rounded-xl cursor-pointer"
        >
          <Home className="w-4 h-4" />
          <span>{t(lang, 'goHomeBtn')}</span>
        </button>
      </section>
    );
  }

  const handlePushAndBuild = async () => {
    if (!vault.githubToken.trim()) {
      onOpenSettings();
      return;
    }
    setIsPushing(true);
    setErrorMsg(null);
    try {
      const endpoint = app.isGithubSynced
        ? '/api/github/update-and-bump'
        : '/api/github/create-and-push';
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-github-token': vault.githubToken.trim(),
        },
        body: JSON.stringify({
          owner,
          repo: app.repoName,
          description: app.description,
          files: app.files.map((f) => ({ path: f.path, content: f.content })),
          commitMessage: `build: trigger APK & Play Store AAB release`,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Push failed.');

      onUpdateApp({
        ...app,
        repoOwner: owner,
        isGithubSynced: true,
        versionCode: data.versionCode ?? app.versionCode,
        versionName: data.versionName ?? app.versionName,
        lastCommitSha: data.commitSha,
      });

      setTimeout(fetchRuns, 2000);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to trigger build.');
    } finally {
      setIsPushing(false);
    }
  };

  const handleDownloadArtifact = async (
    artifact: GitHubArtifact,
    kind: 'apk' | 'aab'
  ) => {
    setDownloadingKind(kind);
    setErrorMsg(null);
    try {
      const res = await fetch('/api/github/download-artifact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-github-token': vault.githubToken.trim(),
        },
        body: JSON.stringify({
          owner,
          repo: app.repoName,
          artifactId: artifact.id,
          targetExt: kind,
        }),
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || 'Artifact download failed.');
      }

      const blob = await res.blob();
      const disposition = res.headers.get('Content-Disposition') ?? '';
      const fileMatch = disposition.match(/filename="([^"]+)"/);
      const fileName = fileMatch
        ? fileMatch[1]
        : `${app.repoName}-v${app.versionName}.${kind}`;

      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Download failed.');
    } finally {
      setDownloadingKind(null);
    }
  };

  const latestRun = runs[0];
  const isBuilding =
    latestRun &&
    (latestRun.status === 'queued' || latestRun.status === 'in_progress');
  const isSuccess =
    latestRun &&
    latestRun.status === 'completed' &&
    latestRun.conclusion === 'success';

  const apkArtifact = artifacts.find((a) => a.kind === 'apk');
  const aabArtifact = artifacts.find((a) => a.kind === 'aab');

  return (
    <section className="max-w-3xl mx-auto space-y-6 pb-8">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-display font-bold text-slate-900 tracking-tight">
            {t(lang, 'buildsTitle')}
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            {t(lang, 'buildsSubtitle')}
          </p>
        </div>

        <button
          type="button"
          onClick={handlePushAndBuild}
          disabled={isPushing}
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-[#1877F2] hover:bg-[#1565D8] rounded-xl whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-60"
        >
          {isPushing ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <GitCommitHorizontal className="w-4 h-4" />
          )}
          <span>{t(lang, 'triggerBuildNow')}</span>
        </button>
      </div>

      {/* App Selector & Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white border border-slate-200 rounded-2xl p-4">
        <select
          value={app.id}
          onChange={(e) => onSwitchApp(e.target.value)}
          className="px-3 py-2 text-sm font-semibold text-slate-900 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-[#1877F2]"
        >
          {allApps.map((item) => (
            <option key={item.id} value={item.id}>
              {lang === 'hi' ? item.nameHi : item.name} ({item.repoName})
            </option>
          ))}
        </select>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setAutoPoll((v) => !v)}
            className={`px-3 py-2 text-xs font-semibold rounded-xl border transition-colors cursor-pointer ${
              autoPoll
                ? 'bg-[#EEF5FF] text-[#1877F2] border-[#D4E4FF]'
                : 'bg-white text-slate-600 border-slate-200'
            }`}
          >
            {autoPoll ? t(lang, 'autoPollingOn') : t(lang, 'autoPollingOff')}
          </button>

          <button
            type="button"
            onClick={fetchRuns}
            disabled={isLoading}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            <span>{t(lang, 'refreshRuns')}</span>
          </button>
        </div>
      </div>

      {errorMsg && (
        <div className="px-4 py-3 rounded-xl bg-red-50 border border-red-200 text-sm text-red-700">
          {errorMsg}
        </div>
      )}

      {latestRun ? (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-100">
            <div className="flex items-start gap-3.5">
              {isBuilding ? (
                <div className="w-10 h-10 rounded-xl bg-[#EEF5FF] text-[#1877F2] flex items-center justify-center shrink-0">
                  <Loader2 className="w-5 h-5 animate-spin" />
                </div>
              ) : isSuccess ? (
                <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
              ) : (
                <div className="w-10 h-10 rounded-xl bg-red-50 text-red-600 flex items-center justify-center shrink-0">
                  <XCircle className="w-5 h-5" />
                </div>
              )}

              <div>
                <h2 className="text-base font-display font-bold text-slate-900">
                  {isBuilding ? t(lang, 'buildingBanner') : latestRun.name}
                </h2>
                <div className="flex items-center flex-wrap gap-2 text-xs text-slate-500 mt-1 tabular-nums">
                  <span>
                    {t(lang, 'workflowRun')} #{latestRun.run_number}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono">
                    {t(lang, 'commitSha')}: {latestRun.head_sha.slice(0, 7)}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="capitalize font-semibold text-slate-700">
                    {latestRun.conclusion ?? latestRun.status}
                  </span>
                </div>
              </div>
            </div>

            <a
              href={latestRun.html_url}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#1877F2] hover:underline shrink-0"
            >
              <span>{t(lang, 'openOnGithub')}</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>

          {steps.length > 0 && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {steps.map((step) => (
                <div
                  key={step.number}
                  className="p-3 rounded-xl border border-slate-200 bg-slate-50/50 flex items-center gap-2.5"
                >
                  {step.status === 'completed' && step.conclusion === 'success' ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  ) : step.status === 'in_progress' ? (
                    <Loader2 className="w-4 h-4 text-[#1877F2] animate-spin shrink-0" />
                  ) : step.conclusion === 'failure' ? (
                    <XCircle className="w-4 h-4 text-red-600 shrink-0" />
                  ) : (
                    <Clock className="w-4 h-4 text-slate-400 shrink-0" />
                  )}
                  <span className="text-xs font-medium text-slate-800 truncate">
                    {step.name}
                  </span>
                </div>
              ))}
            </div>
          )}

          {/* Direct APK & Play Store AAB Buttons */}
          {isSuccess && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-5 rounded-2xl border border-[#D4E4FF] bg-[#EEF5FF]/60 flex flex-col justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 text-sm font-display font-bold text-slate-900">
                    <Smartphone className="w-4 h-4 text-[#1877F2]" />
                    <span>{t(lang, 'downloadInstallApk')}</span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                    {t(lang, 'apkInstallNote')}
                  </p>
                </div>
                <button
                  type="button"
                  disabled={!apkArtifact || downloadingKind === 'apk'}
                  onClick={() =>
                    apkArtifact && handleDownloadArtifact(apkArtifact, 'apk')
                  }
                  className="w-full py-2.5 px-4 inline-flex items-center justify-center gap-2 text-xs font-semibold text-white bg-[#1877F2] hover:bg-[#1565D8] rounded-xl cursor-pointer disabled:opacity-50"
                >
                  {downloadingKind === 'apk' ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Download className="w-4 h-4" />
                  )}
                  <span>{t(lang, 'downloadInstallApk')}</span>
                </button>
              </div>

              <div className="p-5 rounded-2xl border border-slate-200 bg-white flex flex-col justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 text-sm font-display font-bold text-slate-900">
                    <PackageCheck className="w-4 h-4 text-emerald-600" />
                    <span>{t(lang, 'downloadPlayAab')}</span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                    {t(lang, 'aabPlayNote')}
                  </p>
                </div>
                <button
                  type="button"
                  disabled={!aabArtifact || downloadingKind === 'aab'}
                  onClick={() =>
                    aabArtifact && handleDownloadArtifact(aabArtifact, 'aab')
                  }
                  className="w-full py-2.5 px-4 inline-flex items-center justify-center gap-2 text-xs font-semibold text-slate-900 bg-white border border-slate-300 hover:bg-slate-50 rounded-xl cursor-pointer disabled:opacity-50"
                >
                  {downloadingKind === 'aab' ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Download className="w-4 h-4" />
                  )}
                  <span>{t(lang, 'downloadPlayAab')}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center space-y-3">
          <h2 className="text-base font-display font-bold text-slate-900">
            {t(lang, 'noBuildsYet')}
          </h2>
          <p className="text-sm text-slate-500 max-w-md mx-auto">
            {t(lang, 'noBuildsHint')}
          </p>
        </div>
      )}
    </section>
  );
};

import React, { useEffect, useRef, useState } from 'react';
import {
  CheckCircle2,
  ExternalLink,
  FileJson,
  Flame,
  PhoneCall,
  X,
} from 'lucide-react';
import { Language, SavedAndroidApp, VaultSettings } from '../types/studio';
import { t } from '../i18n/translations';
import { validateGoogleServicesJson } from '../utils/googleServices';

interface CreateAppModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreate: (data: {
    appName: string;
    packageName: string;
    repoName: string;
    description: string;
    includeFirebase: boolean;
    includeZegoCloud: boolean;
    googleServicesJson?: string;
    googleServicesPackage?: string;
  }) => void;
  onSaveIntegrations?: (data: {
    includeFirebase: boolean;
    includeZegoCloud: boolean;
    googleServicesJson?: string;
    googleServicesPackage?: string;
  }) => void;
  editingApp?: SavedAndroidApp | null;
  vault: VaultSettings;
  lang: Language;
}

export const CreateAppModal: React.FC<CreateAppModalProps> = ({
  isOpen,
  onClose,
  onCreate,
  onSaveIntegrations,
  editingApp,
  vault,
  lang,
}) => {
  const defaultPrefix = vault.defaultPackagePrefix || 'com.shakya';
  const [appName, setAppName] = useState('');
  const [packageName, setPackageName] = useState(`${defaultPrefix}.myapp`);
  const [repoName, setRepoName] = useState('my-android-app');
  const [description, setDescription] = useState('');
  const [packageEdited, setPackageEdited] = useState(false);
  const [repoEdited, setRepoEdited] = useState(false);

  const [includeFirebase, setIncludeFirebase] = useState(false);
  const [includeZegoCloud, setIncludeZegoCloud] = useState(false);
  const [googleServicesJson, setGoogleServicesJson] = useState<string>('');
  const [googleServicesPackage, setGoogleServicesPackage] = useState<string>('');
  const [firebaseNotice, setFirebaseNotice] = useState<{
    type: 'success' | 'error' | 'info';
    text: string;
  } | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!isOpen) return;
    if (editingApp) {
      setAppName(editingApp.name);
      setPackageName(editingApp.packageName);
      setRepoName(editingApp.repoName);
      setDescription(editingApp.description);
      setIncludeFirebase(editingApp.includeFirebase);
      setIncludeZegoCloud(editingApp.includeZegoCloud);
      setGoogleServicesJson(editingApp.googleServicesJson || '');
      setGoogleServicesPackage(editingApp.googleServicesPackage || '');
      setFirebaseNotice(null);
    } else {
      setAppName('');
      setPackageName(`${defaultPrefix}.myapp`);
      setRepoName('my-android-app');
      setDescription('');
      setPackageEdited(false);
      setRepoEdited(false);
      setIncludeFirebase(false);
      setIncludeZegoCloud(false);
      setGoogleServicesJson(vault.defaultGoogleServicesJson || '');
      setGoogleServicesPackage(vault.defaultGoogleServicesPackage || '');
      setFirebaseNotice(null);
    }
  }, [isOpen, editingApp, defaultPrefix, vault.defaultGoogleServicesJson, vault.defaultGoogleServicesPackage]);

  if (!isOpen) return null;

  const isEditMode = Boolean(editingApp);

  const handleNameChange = (val: string) => {
    setAppName(val);
    const slug = val
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '')
      .slice(0, 24);
    const kebab = val
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '')
      .slice(0, 32);

    if (!packageEdited) {
      setPackageName(`${defaultPrefix}.${slug || 'myapp'}`);
    }
    if (!repoEdited) {
      setRepoName(kebab || 'my-android-app');
    }
  };

  const handleOneTapFirebaseId = async () => {
    const pkg = packageName.trim();
    if (!pkg) return;
    try {
      await navigator.clipboard.writeText(pkg);
      setFirebaseNotice({
        type: 'info',
        text: `${t(lang, 'copiedPackageNotice')} (${pkg})`,
      });
    } catch {
      setFirebaseNotice({
        type: 'info',
        text: `Package ID: ${pkg}`,
      });
    }
    window.open('https://console.firebase.google.com/', '_blank', 'noopener,noreferrer');
  };

  const handleFilePicked = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const rawText = await file.text();
    const res = validateGoogleServicesJson(rawText, packageName.trim());
    if (!res.valid) {
      setFirebaseNotice({
        type: 'error',
        text:
          res.error ||
          `${t(lang, 'googleServicesMismatch')} ${packageName.trim()}`,
      });
      return;
    }

    setGoogleServicesJson(rawText);
    setGoogleServicesPackage(res.matchedPackage || packageName.trim());
    setFirebaseNotice({
      type: 'success',
      text: `${t(lang, 'googleServicesValid')} ${res.matchedPackage}`,
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isEditMode && onSaveIntegrations) {
      onSaveIntegrations({
        includeFirebase,
        includeZegoCloud,
        googleServicesJson: googleServicesJson || undefined,
        googleServicesPackage: googleServicesPackage || undefined,
      });
      onClose();
      return;
    }

    if (!appName.trim()) return;
    onCreate({
      appName: appName.trim(),
      packageName: packageName.trim() || `${defaultPrefix}.app`,
      repoName: repoName.trim() || 'shakya-android-app',
      description:
        description.trim() ||
        'Android Kotlin & Jetpack Compose app built with Shakya AI Studio.',
      includeFirebase,
      includeZegoCloud,
      googleServicesJson: googleServicesJson || undefined,
      googleServicesPackage: googleServicesPackage || undefined,
    });
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-[2px] p-4"
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full max-w-xl max-h-[90vh] overflow-y-auto bg-white border border-slate-200 rounded-2xl shadow-xl">
        <div className="sticky top-0 bg-white z-10 flex items-start justify-between gap-4 px-6 py-5 border-b border-slate-100">
          <div>
            <h2 className="text-lg font-display font-bold text-slate-900">
              {isEditMode ? editingApp?.name : t(lang, 'newAppModalTitle')}
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              {t(lang, 'newAppModalSubtitle')}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 cursor-pointer"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {!isEditMode && (
            <>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  {t(lang, 'appNameLabel')}
                </label>
                <input
                  type="text"
                  required
                  value={appName}
                  onChange={(e) => handleNameChange(e.target.value)}
                  placeholder={t(lang, 'appNamePlaceholder')}
                  className="w-full px-3.5 py-2.5 text-sm border border-slate-200 rounded-xl focus:outline-none focus:border-[#1877F2] focus:ring-2 focus:ring-[#1877F2]/15"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    {t(lang, 'packageNameLabel')}
                  </label>
                  <input
                    type="text"
                    required
                    value={packageName}
                    onChange={(e) => {
                      setPackageEdited(true);
                      setPackageName(e.target.value);
                    }}
                    placeholder={t(lang, 'packageNamePlaceholder')}
                    className="w-full px-3.5 py-2.5 text-xs font-mono border border-slate-200 rounded-xl focus:outline-none focus:border-[#1877F2]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    {t(lang, 'repoNameLabel')}
                  </label>
                  <input
                    type="text"
                    required
                    value={repoName}
                    onChange={(e) => {
                      setRepoEdited(true);
                      setRepoName(e.target.value);
                    }}
                    placeholder={t(lang, 'repoNamePlaceholder')}
                    className="w-full px-3.5 py-2.5 text-xs font-mono border border-slate-200 rounded-xl focus:outline-none focus:border-[#1877F2]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  {t(lang, 'appIdeaLabel')}
                </label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder={t(lang, 'appIdeaPlaceholder')}
                  className="w-full px-3.5 py-2.5 text-sm border border-slate-200 rounded-xl focus:outline-none focus:border-[#1877F2] resize-none"
                />
              </div>
            </>
          )}

          {/* One-Touch Firebase Toggle + Helper */}
          <div className="border border-slate-200 rounded-2xl p-4 space-y-3.5">
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
                  <Flame className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-sm font-semibold text-slate-900">
                    {t(lang, 'includeFirebaseLabel')}
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {t(lang, 'includeFirebaseDesc')}
                  </p>
                </div>
              </div>

              <button
                type="button"
                role="switch"
                aria-checked={includeFirebase}
                onClick={() => setIncludeFirebase((v) => !v)}
                className={`w-11 h-6 rounded-full p-0.5 transition-colors shrink-0 cursor-pointer ${
                  includeFirebase ? 'bg-[#1877F2]' : 'bg-slate-200'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${
                    includeFirebase ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {includeFirebase && (
              <div className="pt-2 border-t border-slate-100 space-y-3">
                <div className="flex flex-wrap gap-2.5">
                  <button
                    type="button"
                    onClick={handleOneTapFirebaseId}
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-[#1877F2] bg-[#EEF5FF] hover:bg-[#dcebff] rounded-lg transition-colors cursor-pointer"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>{t(lang, 'oneTapFirebaseId')}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
                  >
                    <FileJson className="w-3.5 h-3.5" />
                    <span>{t(lang, 'selectGoogleServices')}</span>
                  </button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".json,application/json"
                    onChange={handleFilePicked}
                    className="hidden"
                  />
                </div>

                {googleServicesPackage && !firebaseNotice && (
                  <div className="flex items-center gap-1.5 text-xs text-emerald-700">
                    <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                    <span>
                      {t(lang, 'googleServicesValid')} {googleServicesPackage}
                    </span>
                  </div>
                )}

                {firebaseNotice && (
                  <div
                    className={`p-2.5 rounded-lg text-xs ${
                      firebaseNotice.type === 'error'
                        ? 'bg-red-50 text-red-700 border border-red-200'
                        : firebaseNotice.type === 'success'
                          ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                          : 'bg-[#EEF5FF] text-[#1877F2] border border-[#D4E4FF]'
                    }`}
                  >
                    {firebaseNotice.text}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Automatic ZegoCloud Toggle */}
          <div className="border border-slate-200 rounded-2xl p-4 space-y-2.5">
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-[#EEF5FF] text-[#1877F2] flex items-center justify-center shrink-0">
                  <PhoneCall className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-sm font-semibold text-slate-900">
                    {t(lang, 'includeZegoLabel')}
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {t(lang, 'includeZegoDesc')}
                  </p>
                </div>
              </div>

              <button
                type="button"
                role="switch"
                aria-checked={includeZegoCloud}
                onClick={() => setIncludeZegoCloud((v) => !v)}
                className={`w-11 h-6 rounded-full p-0.5 transition-colors shrink-0 cursor-pointer ${
                  includeZegoCloud ? 'bg-[#1877F2]' : 'bg-slate-200'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${
                    includeZegoCloud ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {includeZegoCloud && (
              <div className="pt-2 border-t border-slate-100 text-xs">
                {vault.zegoAppId.trim() ? (
                  <span className="text-emerald-700 font-medium">
                    {t(lang, 'zegoInheritedNote')}:{' '}
                    <span className="font-mono">{vault.zegoAppId}</span>
                  </span>
                ) : (
                  <span className="text-amber-700">
                    {t(lang, 'zegoMissingNote')}
                  </span>
                )}
              </div>
            )}
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-slate-600 hover:text-slate-900 rounded-xl hover:bg-slate-100 cursor-pointer"
            >
              {t(lang, 'cancel')}
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 text-sm font-semibold text-white bg-[#1877F2] hover:bg-[#1565D8] rounded-xl transition-colors cursor-pointer"
            >
              {isEditMode ? t(lang, 'saveConfig') : t(lang, 'createAndOpen')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import {
  Check,
  Code2,
  Copy,
  GitCommitHorizontal,
  Home,
  Loader2,
  Send,
  SlidersHorizontal,
  Smartphone,
  Sparkles,
} from 'lucide-react';
import {
  ComposePreviewSpec,
  Language,
  SavedAndroidApp,
  VaultSettings,
} from '../types/studio';
import { t } from '../i18n/translations';
import { PhonePreview } from './PhonePreview';

interface WorkspaceViewProps {
  app: SavedAndroidApp | null;
  allApps: SavedAndroidApp[];
  onSwitchApp: (appId: string) => void;
  onUpdateApp: (updated: SavedAndroidApp) => void;
  onOpenIntegrations: () => void;
  onOpenSettings: () => void;
  onGoHome: () => void;
  vault: VaultSettings;
  lang: Language;
}

export const WorkspaceView: React.FC<WorkspaceViewProps> = ({
  app,
  allApps,
  onSwitchApp,
  onUpdateApp,
  onOpenIntegrations,
  onOpenSettings,
  onGoHome,
  vault,
  lang,
}) => {
  const [studioMode, setStudioMode] = useState<'chat' | 'preview'>('chat');
  const [showKotlinCode, setShowKotlinCode] = useState(false);
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isPushing, setIsPushing] = useState(false);
  const [selectedFilePath, setSelectedFilePath] = useState('');
  const [copiedPath, setCopiedPath] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);

  if (!app) {
    return (
      <section className="max-w-xl mx-auto py-16 text-center space-y-4">
        <div className="w-12 h-12 rounded-2xl bg-[#EEF5FF] text-[#1877F2] flex items-center justify-center mx-auto">
          <Sparkles className="w-6 h-6" />
        </div>
        <h2 className="text-xl font-display font-bold text-slate-900">
          {t(lang, 'studioEmptyTitle')}
        </h2>
        <p className="text-sm text-slate-500">{t(lang, 'studioEmptyDesc')}</p>
        <button
          type="button"
          onClick={onGoHome}
          className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-[#1877F2] hover:bg-[#1565D8] rounded-xl cursor-pointer"
        >
          <Home className="w-4 h-4" />
          <span>{t(lang, 'goHomeBtn')}</span>
        </button>
      </section>
    );
  }

  const activeFile =
    app.files.find((f) => f.path === selectedFilePath) ??
    app.files.find((f) => f.path.endsWith('MainActivity.kt')) ??
    app.files[0];

  const handleSendPrompt = async (customPrompt?: string) => {
    const text = (customPrompt ?? prompt).trim();
    if (!text || isGenerating) return;

    if (!vault.geminiApiKey.trim()) {
      setStatusMessage({
        type: 'error',
        text: t(lang, 'geminiKeyRequiredError'),
      });
      onOpenSettings();
      return;
    }

    setStatusMessage(null);
    setIsGenerating(true);

    const nowTime = new Date().toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
    });

    const userMsg = {
      id: `u-${Date.now()}`,
      role: 'user' as const,
      text,
      timestamp: nowTime,
    };

    const mainAct = app.files.find((f) => f.path.endsWith('MainActivity.kt'));

    try {
      const res = await fetch('/api/gemini/build-android', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-gemini-api-key': vault.geminiApiKey.trim(),
        },
        body: JSON.stringify({
          prompt: text,
          appMeta: {
            name: app.name,
            packageName: app.packageName,
            versionName: app.versionName,
            versionCode: app.versionCode,
          },
          currentPreview: app.previewSpec,
          mainActivityCode: mainAct?.content ?? '',
          language: lang,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Gemini generation failed.');
      }

      const updatedSpec: ComposePreviewSpec = data.updatedPreviewSpec;
      const newMainKotlin: string = data.mainActivityKotlin;

      const updatedFiles = app.files.map((f) =>
        f.path.endsWith('MainActivity.kt') ? { ...f, content: newMainKotlin } : f
      );

      const assistantMsg = {
        id: `a-${Date.now()}`,
        role: 'assistant' as const,
        text: data.reply,
        timestamp: new Date().toLocaleTimeString([], {
          hour: '2-digit',
          minute: '2-digit',
        }),
        updatedFiles: mainAct ? [mainAct.path] : [],
      };

      onUpdateApp({
        ...app,
        lastUpdated: new Date().toISOString().slice(0, 16).replace('T', ' '),
        previewSpec: updatedSpec,
        files: updatedFiles,
        chatHistory: [...app.chatHistory, userMsg, assistantMsg],
      });

      if (!customPrompt) setPrompt('');
      setStudioMode('preview');
    } catch (err) {
      setStatusMessage({
        type: 'error',
        text: err instanceof Error ? err.message : 'Generation error',
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handlePushToGithub = async () => {
    if (!vault.githubToken.trim()) {
      setStatusMessage({
        type: 'error',
        text:
          lang === 'hi'
            ? 'GitHub पर पुश करने के लिए कृपया Settings में GitHub Token सहेजें।'
            : 'Save your GitHub Personal Access Token in Settings first.',
      });
      onOpenSettings();
      return;
    }

    setIsPushing(true);
    setStatusMessage(null);

    try {
      const endpoint = app.isGithubSynced
        ? '/api/github/update-and-bump'
        : '/api/github/create-and-push';

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-github-token': vault.githubToken.trim(),
        },
        body: JSON.stringify({
          owner: vault.githubUsername.trim() || app.repoOwner,
          repo: app.repoName,
          description: app.description,
          files: app.files.map((f) => ({ path: f.path, content: f.content })),
          commitMessage: `feat: update ${app.name} via Shakya AI Studio`,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'GitHub push failed.');
      }

      const nextCode =
        typeof data.versionCode === 'number' ? data.versionCode : app.versionCode;
      const nextName =
        typeof data.versionName === 'string' ? data.versionName : app.versionName;
      const updatedFiles = data.updatedGradleContent
        ? app.files.map((f) =>
            f.path === 'app/build.gradle.kts'
              ? { ...f, content: data.updatedGradleContent }
              : f
          )
        : app.files;

      onUpdateApp({
        ...app,
        repoOwner: vault.githubUsername.trim() || app.repoOwner,
        isGithubSynced: true,
        versionCode: nextCode,
        versionName: nextName,
        lastCommitSha: data.commitSha,
        lastUpdated: new Date().toISOString().slice(0, 16).replace('T', ' '),
        files: updatedFiles,
      });

      setStatusMessage({
        type: 'success',
        text:
          lang === 'hi'
            ? `GitHub पर पुश सफल (v${nextName} / Build ${nextCode})।`
            : `Pushed directly to GitHub (v${nextName} / Build ${nextCode}).`,
      });
    } catch (err) {
      setStatusMessage({
        type: 'error',
        text: err instanceof Error ? err.message : 'GitHub push failed.',
      });
    } finally {
      setIsPushing(false);
    }
  };

  const handleCopyFile = async (path: string, content: string) => {
    await navigator.clipboard.writeText(content);
    setCopiedPath(path);
    setTimeout(() => setCopiedPath(null), 1500);
  };

  return (
    <section className="max-w-4xl mx-auto space-y-5 pb-6">
      {/* Clean Studio Toolbar */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          <select
            value={app.id}
            onChange={(e) => onSwitchApp(e.target.value)}
            className="px-3 py-2 text-sm font-display font-bold text-slate-900 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-[#1877F2]"
          >
            {allApps.map((item) => (
              <option key={item.id} value={item.id}>
                {lang === 'hi' ? item.nameHi : item.name}
              </option>
            ))}
          </select>

          <span className="text-xs font-mono text-slate-500 tabular-nums">
            v{app.versionName} · {t(lang, 'buildLabel')} {app.versionCode}
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={onOpenIntegrations}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl cursor-pointer"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>{t(lang, 'appConfigBtn')}</span>
          </button>

          <button
            type="button"
            onClick={handlePushToGithub}
            disabled={isPushing}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-[#1877F2] hover:bg-[#1565D8] rounded-xl cursor-pointer disabled:opacity-60"
          >
            {isPushing ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <GitCommitHorizontal className="w-3.5 h-3.5" />
            )}
            <span>
              {isPushing
                ? t(lang, 'pushingGithub')
                : app.isGithubSynced
                  ? t(lang, 'pushToGithub')
                  : t(lang, 'initGithubRepo')}
            </span>
          </button>
        </div>
      </div>

      {/* Top Mode Switch: AI Chat vs Live Mobile Screen */}
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl">
          <button
            type="button"
            onClick={() => {
              setStudioMode('chat');
              setShowKotlinCode(false);
            }}
            className={`inline-flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-colors cursor-pointer ${
              studioMode === 'chat'
                ? 'bg-white text-[#1877F2] shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>{t(lang, 'tabAiChat')}</span>
          </button>

          <button
            type="button"
            onClick={() => setStudioMode('preview')}
            className={`inline-flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-colors cursor-pointer ${
              studioMode === 'preview'
                ? 'bg-white text-[#1877F2] shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>{t(lang, 'tabLiveScreen')}</span>
          </button>
        </div>

        {studioMode === 'preview' && (
          <button
            type="button"
            onClick={() => setShowKotlinCode((v) => !v)}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl cursor-pointer"
          >
            <Code2 className="w-3.5 h-3.5" />
            <span>
              {showKotlinCode
                ? t(lang, 'hideKotlinCodeBtn')
                : t(lang, 'viewKotlinCodeBtn')}
            </span>
          </button>
        )}
      </div>

      {statusMessage && (
        <div
          className={`px-4 py-3 rounded-xl border text-xs sm:text-sm ${
            statusMessage.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-red-50 border-red-200 text-red-700'
          }`}
        >
          {statusMessage.text}
        </div>
      )}

      {/* Full-Screen Spacious Mode Content */}
      {studioMode === 'chat' ? (
        <div className="bg-white border border-slate-200 rounded-2xl flex flex-col min-h-[540px]">
          <div className="px-6 py-4 border-b border-slate-100">
            <p className="text-xs sm:text-sm text-slate-500">
              {t(lang, 'aiBuilderSubtitle')}
            </p>
          </div>

          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {app.chatHistory.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col ${
                  msg.role === 'user' ? 'items-end' : 'items-start'
                }`}
              >
                <div
                  className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                    msg.role === 'user'
                      ? 'bg-[#1877F2] text-white'
                      : 'bg-slate-50 border border-slate-200 text-slate-800'
                  }`}
                >
                  <p>{msg.text}</p>
                </div>
                <span className="text-[11px] text-slate-400 mt-1 tabular-nums">
                  {msg.timestamp}
                </span>
              </div>
            ))}

            {isGenerating && (
              <div className="flex items-center gap-2.5 text-xs font-medium text-[#1877F2] bg-[#EEF5FF] px-4 py-3 rounded-xl">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>{t(lang, 'generating')}</span>
              </div>
            )}
          </div>

          <div className="p-5 border-t border-slate-100 space-y-3 bg-slate-50/50 rounded-b-2xl">
            <div className="flex flex-wrap gap-2">
              {[
                t(lang, 'quickPrompt1'),
                t(lang, 'quickPrompt2'),
                t(lang, 'quickPrompt3'),
              ].map((suggestion) => (
                <button
                  key={suggestion}
                  type="button"
                  onClick={() => handleSendPrompt(suggestion)}
                  disabled={isGenerating}
                  className="text-left text-xs text-slate-700 bg-white hover:bg-[#EEF5FF] hover:text-[#1877F2] border border-slate-200 px-3 py-1.5 rounded-lg transition-colors cursor-pointer disabled:opacity-50"
                >
                  {suggestion}
                </button>
              ))}
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendPrompt();
              }}
              className="flex items-end gap-2.5"
            >
              <textarea
                rows={2}
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendPrompt();
                  }
                }}
                placeholder={t(lang, 'promptPlaceholder')}
                className="flex-1 px-4 py-3 text-sm bg-white border border-slate-200 rounded-xl focus:outline-none focus:border-[#1877F2] focus:ring-2 focus:ring-[#1877F2]/15 resize-none"
              />
              <button
                type="submit"
                disabled={isGenerating || !prompt.trim()}
                className="h-[48px] px-5 inline-flex items-center gap-2 text-sm font-semibold text-white bg-[#1877F2] hover:bg-[#1565D8] rounded-xl transition-colors cursor-pointer disabled:opacity-50 shrink-0"
              >
                <Send className="w-4 h-4" />
                <span>{t(lang, 'sendPrompt')}</span>
              </button>
            </form>
          </div>
        </div>
      ) : !showKotlinCode ? (
        <div className="bg-slate-50/50 border border-slate-200 rounded-2xl p-6 sm:p-8 flex items-center justify-center">
          <PhonePreview
            spec={app.previewSpec}
            studioLang={lang}
            versionName={app.versionName}
            versionCode={app.versionCode}
          />
        </div>
      ) : (
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden flex flex-col min-h-[540px]">
          <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between gap-3 bg-slate-50">
            <select
              value={activeFile?.path ?? ''}
              onChange={(e) => setSelectedFilePath(e.target.value)}
              className="text-xs font-mono bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 max-w-[340px]"
            >
              {app.files.map((f) => (
                <option key={f.path} value={f.path}>
                  {f.path}
                </option>
              ))}
            </select>

            {activeFile && (
              <button
                type="button"
                onClick={() =>
                  handleCopyFile(activeFile.path, activeFile.content)
                }
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 rounded-lg cursor-pointer"
              >
                {copiedPath === activeFile.path ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{t(lang, 'copied')}</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>{t(lang, 'copyFile')}</span>
                  </>
                )}
              </button>
            )}
          </div>

          <pre className="flex-1 p-5 overflow-auto text-xs font-mono text-slate-800 leading-relaxed max-h-[540px]">
            <code>{activeFile?.content ?? ''}</code>
          </pre>
        </div>
      )}
    </section>
  );
};

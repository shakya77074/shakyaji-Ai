import React from 'react';
import { Download, Home, Settings, Sparkles } from 'lucide-react';
import { Language, StudioView } from '../types/studio';
import { t } from '../i18n/translations';

interface BottomNavProps {
  activeView: StudioView;
  onNavigate: (view: StudioView) => void;
  lang: Language;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeView,
  onNavigate,
  lang,
}) => {
  const tabs: Array<{
    id: StudioView;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
  }> = [
    { id: 'home', label: t(lang, 'navHome'), icon: Home },
    { id: 'studio', label: t(lang, 'navStudio'), icon: Sparkles },
    { id: 'builds', label: t(lang, 'navBuilds'), icon: Download },
    { id: 'settings', label: t(lang, 'navSettings'), icon: Settings },
  ];

  return (
    <nav
      aria-label="Primary Navigation"
      className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-slate-200"
    >
      <div className="max-w-5xl mx-auto grid grid-cols-4 h-16">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const active = activeView === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => onNavigate(tab.id)}
              className={`flex flex-col items-center justify-center gap-1 min-h-[44px] transition-colors cursor-pointer ${
                active
                  ? 'text-[#1877F2]'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <div
                className={`px-3 py-1 rounded-full transition-colors ${
                  active ? 'bg-[#EEF5FF]' : ''
                }`}
              >
                <Icon className="w-5 h-5" />
              </div>
              <span
                className={`text-[11px] whitespace-nowrap ${
                  active ? 'font-semibold text-[#1877F2]' : 'font-medium'
                }`}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};

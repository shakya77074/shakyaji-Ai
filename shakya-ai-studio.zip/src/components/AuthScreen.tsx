import React, { useState } from 'react';
import { signInWithPopup } from 'firebase/auth';
import { Languages, Loader2, ShieldCheck } from 'lucide-react';
import { auth, googleProvider } from '../firebase';
import { Language } from '../types/studio';
import { t } from '../i18n/translations';

interface AuthScreenProps {
  lang: Language;
  onToggleLang: () => void;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({
  lang,
  onToggleLang,
}) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGoogleSignIn = async () => {
    setLoading(true);
    setError(null);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      if (msg.includes('auth/popup-closed-by-user')) {
        setError(
          lang === 'hi'
            ? 'Google साइन-इन विंडो बंद कर दी गई।'
            : 'Google sign-in popup was closed.'
        );
      } else {
        setError(msg);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-white flex flex-col justify-between px-4 sm:px-6 py-6">
      {/* Top Bar */}
      <header className="max-w-5xl w-full mx-auto flex items-center justify-between gap-4">
        <span className="text-xl font-display font-bold tracking-tight text-[#1877F2]">
          {t(lang, 'brandName')}
        </span>

        <button
          type="button"
          onClick={onToggleLang}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#1877F2] bg-[#EEF5FF] hover:bg-[#dcebff] rounded-lg transition-colors cursor-pointer"
        >
          <Languages className="w-3.5 h-3.5" />
          <span>{lang === 'en' ? 'हिंदी' : 'English'}</span>
        </button>
      </header>

      {/* Center Google-Only Auth Card */}
      <main className="w-full max-w-md mx-auto my-10">
        <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 space-y-6 text-center">
          <div className="w-12 h-12 rounded-2xl bg-[#EEF5FF] text-[#1877F2] flex items-center justify-center mx-auto">
            <ShieldCheck className="w-6 h-6" />
          </div>

          <div className="space-y-2">
            <h1 className="text-2xl font-display font-bold text-slate-900 tracking-tight">
              {t(lang, 'authTitleSignIn')}
            </h1>
            <p className="text-sm text-slate-500 leading-relaxed">
              {t(lang, 'authSubtitle')}
            </p>
          </div>

          {error && (
            <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 text-xs text-red-700 leading-relaxed text-left">
              {error}
            </div>
          )}

          <button
            type="button"
            onClick={handleGoogleSignIn}
            disabled={loading}
            className="w-full py-3 px-4 bg-[#1877F2] hover:bg-[#1565D8] text-white rounded-xl text-sm font-semibold flex items-center justify-center gap-3 transition-colors cursor-pointer disabled:opacity-60"
          >
            {loading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <span className="w-6 h-6 rounded-full bg-white flex items-center justify-center shrink-0">
                <svg className="w-4 h-4" viewBox="0 0 24 24" aria-hidden="true">
                  <path
                    fill="#4285F4"
                    d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 24c3.3 0 6.08-1.09 8.1-2.96l-3.88-3.05c-1.1.74-2.51 1.18-4.22 1.18-3.25 0-6-2.19-6.98-5.14H1.01v3.14C3.05 21.22 7.2 24 12 24z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.02 14.03A7.18 7.18 0 0 1 4.64 12c0-.7.13-1.39.38-2.03V6.83H1.01A11.97 11.97 0 0 0 0 12c0 1.94.46 3.77 1.01 5.17l4.01-3.14z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 4.75c1.8 0 3.41.62 4.68 1.84l3.51-3.51C18.07 1.19 15.3 0 12 0 7.2 0 3.05 2.78 1.01 6.83l4.01 3.14C6 6.94 8.75 4.75 12 4.75z"
                  />
                </svg>
              </span>
            )}
            <span>{t(lang, 'continueWithGoogle')}</span>
          </button>
        </div>
      </main>

      {/* Bottom Disclaimer + Branding */}
      <footer className="max-w-lg w-full mx-auto text-center space-y-3">
        <p className="text-xs text-slate-500 leading-relaxed bg-slate-50 border border-slate-200 rounded-xl px-4 py-3">
          {t(lang, 'authDisclaimer')}
        </p>
        <div className="text-xs font-semibold text-slate-400">
          {t(lang, 'fromShakya')}
        </div>
      </footer>
    </div>
  );
};

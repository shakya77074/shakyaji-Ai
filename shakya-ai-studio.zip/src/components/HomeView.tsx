import React from 'react';
import { ArrowRight, Plus, Smartphone } from 'lucide-react';
import { Language, SavedAndroidApp, VaultSettings } from '../types/studio';
import { t } from '../i18n/translations';

interface HomeViewProps {
  apps: SavedAndroidApp[];
  vault: VaultSettings;
  lang: Language;
  onOpenApp: (appId: string) => void;
  onOpenCreateModal: () => void;
  onStartSetup: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  apps,
  vault,
  lang,
  onOpenApp,
  onOpenCreateModal,
  onStartSetup,
}) => {
  // Show onboarding card automatically until Gemini API Key & GitHub Token are configured
  const needsFirstTimeSetup =
    !vault.geminiApiKey.trim() || !vault.githubToken.trim();

  return (
    <section className="max-w-3xl mx-auto space-y-6 pb-8">
      {/* First-Time User Onboarding Card */}
      {needsFirstTimeSetup && (
        <div className="bg-[#EEF5FF] border border-[#D4E4FF] rounded-2xl p-6 space-y-4">
          <h2 className="text-base font-display font-bold text-[#1877F2]">
            {t(lang, 'onboardingTitle')}
          </h2>
          <ol className="space-y-2 text-sm text-slate-800">
            <li className="font-medium">{t(lang, 'onboardingStep1')}</li>
            <li className="font-medium">{t(lang, 'onboardingStep2')}</li>
            <li className="font-medium">{t(lang, 'onboardingStep3')}</li>
          </ol>
          <button
            type="button"
            onClick={onStartSetup}
            className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-white bg-[#1877F2] hover:bg-[#1565D8] rounded-xl transition-colors cursor-pointer"
          >
            <span>{t(lang, 'startSetupBtn')}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Primary Action & Heading */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h1 className="text-2xl font-display font-bold text-slate-900 tracking-tight">
          {t(lang, 'homeTitle')}
        </h1>

        <button
          type="button"
          onClick={onOpenCreateModal}
          className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-[#1877F2] hover:bg-[#1565D8] rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>{t(lang, 'createNewApp').replace(/^\+\s*/, '')}</span>
        </button>
      </div>

      {/* Minimal List of User's Real Saved Apps (Zero Demo Apps) */}
      {apps.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-[#EEF5FF] text-[#1877F2] flex items-center justify-center mx-auto">
            <Smartphone className="w-6 h-6" />
          </div>
          <h3 className="text-base font-display font-bold text-slate-900">
            {t(lang, 'noSavedAppsTitle')}
          </h3>
          <p className="text-sm text-slate-500 max-w-md mx-auto">
            {t(lang, 'noSavedAppsDesc')}
          </p>
        </div>
      ) : (
        <div className="divide-y divide-slate-200 bg-white border border-slate-200 rounded-2xl overflow-hidden">
          {apps.map((app) => {
            const displayName = lang === 'hi' ? app.nameHi : app.name;
            const flags: string[] = [];
            if (app.includeFirebase) flags.push(t(lang, 'firebaseEnabled'));
            if (app.includeZegoCloud) flags.push(t(lang, 'zegoEnabled'));

            return (
              <div
                key={app.id}
                className="p-5 flex items-center justify-between gap-4 hover:bg-slate-50/70 transition-colors"
              >
                <div className="min-w-0 space-y-1">
                  <div className="text-base font-display font-bold text-slate-900 truncate">
                    {displayName}
                  </div>
                  <div className="text-xs font-mono text-slate-500 truncate">
                    {app.packageName}
                  </div>
                  <div className="text-xs text-slate-500 flex items-center flex-wrap gap-2 tabular-nums">
                    <span className="font-semibold text-slate-700">
                      v{app.versionName} ({t(lang, 'buildLabel')} {app.versionCode})
                    </span>
                    {flags.length > 0 && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="text-[#1877F2] font-medium">
                          {flags.join(' · ')}
                        </span>
                      </>
                    )}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => onOpenApp(app.id)}
                  className="px-4 py-2 text-xs font-semibold text-white bg-[#1877F2] hover:bg-[#1565D8] rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  {t(lang, 'openBtn')}
                </button>
              </div>
            );
          })}
        </div>
      )}

      {/* Subtle Home Footer */}
      <div className="pt-4 text-center text-xs font-semibold text-slate-400">
        {t(lang, 'fromShakya')}
      </div>
    </section>
  );
};

import React, { useRef, useState } from 'react';
import JSZip from 'jszip';
import {
  CheckCircle2,
  Download,
  Eye,
  EyeOff,
  FileJson,
  FolderGit2,
  KeyRound,
  Loader2,
  LogOut,
  PhoneCall,
  Save,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import { generateShakyaStudioKotlinProject } from '../data/androidTemplate';
import { GitHubUserProfile, Language, VaultSettings } from '../types/studio';
import { t } from '../i18n/translations';
import { validateGoogleServicesJson } from '../utils/googleServices';

interface VaultViewProps {
  vault: VaultSettings;
  userEmail: string | null;
  onSaveVault: (next: VaultSettings) => void;
  onLogOut: () => Promise<void>;
  lang: Language;
}

export const VaultView: React.FC<VaultViewProps> = ({
  vault,
  userEmail,
  onSaveVault,
  onLogOut,
  lang,
}) => {
  const [form, setForm] = useState<VaultSettings>(vault);
  const [showGeminiKey, setShowGeminiKey] = useState(false);
  const [showToken, setShowToken] = useState(false);
  const [showKeystorePass, setShowKeystorePass] = useState(false);
  const [showZegoSign, setShowZegoSign] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [verifiedUser, setVerifiedUser] = useState<GitHubUserProfile | null>(
    null
  );
  const [verifyError, setVerifyError] = useState<string | null>(null);
  const [googleJsonError, setGoogleJsonError] = useState<string | null>(null);
  const [savedBanner, setSavedBanner] = useState(false);

  const fileRef = useRef<HTMLInputElement>(null);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveVault(form);
    setSavedBanner(true);
    setTimeout(() => setSavedBanner(false), 2600);
  };

  const handleVerifyGithub = async () => {
    if (!form.githubToken.trim()) {
      setVerifyError('Please enter a GitHub Personal Access Token.');
      return;
    }
    setVerifying(true);
    setVerifyError(null);
    setVerifiedUser(null);

    try {
      const res = await fetch('/api/github/verify', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-github-token': form.githubToken.trim(),
        },
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Verification failed.');
      }
      setVerifiedUser(data.user);
      if (data.user?.login) {
        const updated = { ...form, githubUsername: data.user.login };
        setForm(updated);
        onSaveVault(updated);
      }
    } catch (err) {
      setVerifyError(
        err instanceof Error ? err.message : 'GitHub verification failed.'
      );
    } finally {
      setVerifying(false);
    }
  };

  const handleDefaultGoogleJson = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setGoogleJsonError(null);
    const raw = await file.text();
    const res = validateGoogleServicesJson(raw, '');
    if (!res.valid) {
      setGoogleJsonError(res.error || t(lang, 'googleServicesInvalidJson'));
      return;
    }
    setForm((prev) => ({
      ...prev,
      defaultGoogleServicesJson: raw,
      defaultGoogleServicesPackage: res.packagesFound[0] || '',
    }));
  };

  const handleDownloadNativeKotlin = async () => {
    const files = generateShakyaStudioKotlinProject();
    const zip = new JSZip();
    for (const file of files) {
      zip.file(file.path, file.content);
    }
    const blob = await zip.generateAsync({ type: 'blob' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'shakya-ai-studio-kotlin.zip';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <section className="max-w-3xl mx-auto space-y-6 pb-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-display font-bold text-slate-900 tracking-tight">
            {t(lang, 'settingsTitle')}
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            {t(lang, 'settingsSubtitle')}
          </p>
        </div>
        {userEmail && (
          <span className="text-xs font-mono text-slate-500 truncate">
            {userEmail}
          </span>
        )}
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Personal Gemini API Key */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#EEF5FF] text-[#1877F2] flex items-center justify-center shrink-0">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-display font-bold text-slate-900">
                {t(lang, 'geminiKeySectionTitle')}
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                {t(lang, 'geminiKeySectionDesc')}
              </p>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              {t(lang, 'geminiKeyLabel')}
            </label>
            <div className="relative">
              <input
                type={showGeminiKey ? 'text' : 'password'}
                value={form.geminiApiKey}
                onChange={(e) =>
                  setForm({ ...form, geminiApiKey: e.target.value })
                }
                placeholder={t(lang, 'geminiKeyPlaceholder')}
                className="w-full pl-3.5 pr-10 py-2.5 text-sm font-mono border border-slate-200 rounded-xl focus:outline-none focus:border-[#1877F2]"
              />
              <button
                type="button"
                onClick={() => setShowGeminiKey((s) => !s)}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 cursor-pointer"
                aria-label="Toggle Gemini key visibility"
              >
                {showGeminiKey ? (
                  <EyeOff className="w-4 h-4" />
                ) : (
                  <Eye className="w-4 h-4" />
                )}
              </button>
            </div>
          </div>
        </div>

        {/* GitHub Vault */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-5">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#EEF5FF] text-[#1877F2] flex items-center justify-center shrink-0">
              <FolderGit2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-display font-bold text-slate-900">
                {t(lang, 'githubSectionTitle')}
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                {t(lang, 'githubSectionDesc')}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                {t(lang, 'githubUsernameLabel')}
              </label>
              <input
                type="text"
                value={form.githubUsername}
                onChange={(e) =>
                  setForm({ ...form, githubUsername: e.target.value })
                }
                placeholder="shakya77074"
                className="w-full px-3.5 py-2.5 text-sm font-mono border border-slate-200 rounded-xl focus:outline-none focus:border-[#1877F2]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                {t(lang, 'defaultPrefixLabel')}
              </label>
              <input
                type="text"
                value={form.defaultPackagePrefix}
                onChange={(e) =>
                  setForm({ ...form, defaultPackagePrefix: e.target.value })
                }
                placeholder="com.shakya"
                className="w-full px-3.5 py-2.5 text-sm font-mono border border-slate-200 rounded-xl focus:outline-none focus:border-[#1877F2]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              {t(lang, 'githubTokenLabel')}
            </label>
            <div className="flex flex-col sm:flex-row gap-2.5">
              <div className="relative flex-1">
                <input
                  type={showToken ? 'text' : 'password'}
                  value={form.githubToken}
                  onChange={(e) =>
                    setForm({ ...form, githubToken: e.target.value })
                  }
                  placeholder="ghp_xxxxxxxxxxxxxxxxxxxx"
                  className="w-full pl-3.5 pr-10 py-2.5 text-sm font-mono border border-slate-200 rounded-xl focus:outline-none focus:border-[#1877F2]"
                />
                <button
                  type="button"
                  onClick={() => setShowToken((s) => !s)}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 cursor-pointer"
                >
                  {showToken ? (
                    <EyeOff className="w-4 h-4" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                </button>
              </div>

              <button
                type="button"
                onClick={handleVerifyGithub}
                disabled={verifying}
                className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold text-[#1877F2] bg-[#EEF5FF] hover:bg-[#dcebff] rounded-xl whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-60"
              >
                {verifying ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <ShieldCheck className="w-4 h-4" />
                )}
                <span>
                  {verifying ? t(lang, 'verifying') : t(lang, 'verifyGithub')}
                </span>
              </button>
            </div>
          </div>

          {verifiedUser && (
            <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center gap-3">
              <img
                src={verifiedUser.avatar_url}
                alt={verifiedUser.login}
                referrerPolicy="no-referrer"
                className="w-8 h-8 rounded-full border border-emerald-200"
              />
              <div className="text-xs text-emerald-900 font-semibold">
                {t(lang, 'connectedAs')} @{verifiedUser.login}
              </div>
            </div>
          )}

          {verifyError && (
            <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-700">
              {verifyError}
            </div>
          )}
        </div>

        {/* ZegoCloud Global Vault */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#EEF5FF] text-[#1877F2] flex items-center justify-center shrink-0">
              <PhoneCall className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-display font-bold text-slate-900">
                {t(lang, 'zegoSectionTitle')}
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                {t(lang, 'zegoSectionDesc')}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                {t(lang, 'zegoAppIdLabel')}
              </label>
              <input
                type="text"
                value={form.zegoAppId}
                onChange={(e) => setForm({ ...form, zegoAppId: e.target.value })}
                placeholder="e.g. 1234567890"
                className="w-full px-3.5 py-2.5 text-sm font-mono border border-slate-200 rounded-xl focus:outline-none focus:border-[#1877F2]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                {t(lang, 'zegoAppSignLabel')}
              </label>
              <div className="relative">
                <input
                  type={showZegoSign ? 'text' : 'password'}
                  value={form.zegoAppSign}
                  onChange={(e) =>
                    setForm({ ...form, zegoAppSign: e.target.value })
                  }
                  placeholder="64-character hex sign"
                  className="w-full pl-3.5 pr-9 py-2.5 text-sm font-mono border border-slate-200 rounded-xl focus:outline-none focus:border-[#1877F2]"
                />
                <button
                  type="button"
                  onClick={() => setShowZegoSign((s) => !s)}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 cursor-pointer"
                >
                  {showZegoSign ? (
                    <EyeOff className="w-4 h-4" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Default google-services.json */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
              <FileJson className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-display font-bold text-slate-900">
                {t(lang, 'firebaseDefaultTitle')}
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                {t(lang, 'firebaseDefaultDesc')}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl cursor-pointer"
            >
              <FileJson className="w-4 h-4" />
              <span>{t(lang, 'selectDefaultGoogleJson')}</span>
            </button>
            <input
              ref={fileRef}
              type="file"
              accept=".json,application/json"
              onChange={handleDefaultGoogleJson}
              className="hidden"
            />
            {form.defaultGoogleServicesPackage && (
              <span className="text-xs font-mono text-emerald-700">
                {form.defaultGoogleServicesPackage}
              </span>
            )}
          </div>
          {googleJsonError && (
            <div className="text-xs text-red-600">{googleJsonError}</div>
          )}
        </div>

        {/* Play Store Keystore */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center shrink-0">
              <KeyRound className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-display font-bold text-slate-900">
                {t(lang, 'signingSectionTitle')}
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                {t(lang, 'signingSectionDesc')}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                {t(lang, 'keystoreAliasLabel')}
              </label>
              <input
                type="text"
                value={form.keystoreAlias}
                onChange={(e) =>
                  setForm({ ...form, keystoreAlias: e.target.value })
                }
                placeholder="shakya-upload-key"
                className="w-full px-3.5 py-2.5 text-sm font-mono border border-slate-200 rounded-xl focus:outline-none focus:border-[#1877F2]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                {t(lang, 'keystorePasswordLabel')}
              </label>
              <div className="relative">
                <input
                  type={showKeystorePass ? 'text' : 'password'}
                  value={form.keystorePassword}
                  onChange={(e) =>
                    setForm({ ...form, keystorePassword: e.target.value })
                  }
                  placeholder="••••••••"
                  className="w-full pl-3.5 pr-9 py-2.5 text-sm font-mono border border-slate-200 rounded-xl focus:outline-none focus:border-[#1877F2]"
                />
                <button
                  type="button"
                  onClick={() => setShowKeystorePass((s) => !s)}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 cursor-pointer"
                >
                  {showKeystorePass ? (
                    <EyeOff className="w-4 h-4" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                {t(lang, 'keyPasswordLabel')}
              </label>
              <input
                type={showKeystorePass ? 'text' : 'password'}
                value={form.keyPassword}
                onChange={(e) =>
                  setForm({ ...form, keyPassword: e.target.value })
                }
                placeholder="••••••••"
                className="w-full px-3.5 py-2.5 text-sm font-mono border border-slate-200 rounded-xl focus:outline-none focus:border-[#1877F2]"
              />
            </div>
          </div>
        </div>

        {/* Save Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          {savedBanner ? (
            <div className="inline-flex items-center gap-2 text-xs sm:text-sm font-medium text-emerald-700">
              <CheckCircle2 className="w-4 h-4" />
              <span>{t(lang, 'vaultSaved')}</span>
            </div>
          ) : (
            <span />
          )}

          <button
            type="submit"
            className="inline-flex items-center gap-2 px-6 py-2.5 text-sm font-semibold text-white bg-[#1877F2] hover:bg-[#1565D8] rounded-xl transition-colors cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>{t(lang, 'saveVault')}</span>
          </button>
        </div>
      </form>

      {/* Native Android Source Export & Log Out */}
      <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <button
          type="button"
          onClick={handleDownloadNativeKotlin}
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl cursor-pointer"
        >
          <Download className="w-4 h-4" />
          <span>{t(lang, 'exportNativeSourceBtn')}</span>
        </button>

        <button
          type="button"
          onClick={onLogOut}
          className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-xs font-semibold text-red-600 bg-red-50 hover:bg-red-100 border border-red-200 rounded-xl cursor-pointer"
        >
          <LogOut className="w-4 h-4" />
          <span>{t(lang, 'logOutBtn')}</span>
        </button>
      </div>
    </section>
  );
};

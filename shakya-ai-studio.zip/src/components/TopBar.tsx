import React from 'react';
import { Languages } from 'lucide-react';
import { Language } from '../types/studio';
import { t } from '../i18n/translations';

interface TopBarProps {
  lang: Language;
  onToggleLang: () => void;
  onBrandClick: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  lang,
  onToggleLang,
  onBrandClick,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-4">
        <button
          type="button"
          onClick={onBrandClick}
          className="text-lg font-display font-bold tracking-tight text-[#1877F2] whitespace-nowrap shrink-0 cursor-pointer"
        >
          {t(lang, 'brandName')}
        </button>

        <button
          type="button"
          onClick={onToggleLang}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#1877F2] bg-[#EEF5FF] hover:bg-[#dcebff] rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Languages className="w-3.5 h-3.5" />
          <span>{lang === 'en' ? 'English / हिंदी' : 'हिंदी / English'}</span>
        </button>
      </div>
    </header>
  );
};

export interface GoogleServicesValidationResult {
  valid: boolean;
  packagesFound: string[];
  matchedPackage?: string;
  error?: string;
}

export function validateGoogleServicesJson(
  rawJson: string,
  expectedPackageName: string
): GoogleServicesValidationResult {
  try {
    const parsed = JSON.parse(rawJson) as {
      project_info?: { project_id?: string };
      client?: Array<{
        client_info?: {
          android_client_info?: {
            package_name?: string;
          };
        };
      }>;
    };

    if (!parsed || !Array.isArray(parsed.client)) {
      return {
        valid: false,
        packagesFound: [],
        error: 'Missing client array in google-services.json.',
      };
    }

    const packagesFound = parsed.client
      .map((c) => c?.client_info?.android_client_info?.package_name)
      .filter((pkg): pkg is string => typeof pkg === 'string' && pkg.length > 0);

    if (packagesFound.length === 0) {
      return {
        valid: false,
        packagesFound: [],
        error: 'No android_client_info.package_name found in file.',
      };
    }

    const cleanExpected = expectedPackageName.trim();
    if (cleanExpected && !packagesFound.includes(cleanExpected)) {
      return {
        valid: false,
        packagesFound,
        error: `Package mismatch: expected "${cleanExpected}", found "${packagesFound.join(', ')}".`,
      };
    }

    return {
      valid: true,
      packagesFound,
      matchedPackage: cleanExpected || packagesFound[0],
    };
  } catch {
    return {
      valid: false,
      packagesFound: [],
      error: 'Invalid JSON syntax in google-services.json.',
    };
  }
}

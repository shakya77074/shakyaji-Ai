import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import JSZip from 'jszip';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;
const SAFE_SEGMENT = /^[a-zA-Z0-9._-]+$/;

function validateRepoOwnerAndName(owner: unknown, repo: unknown): { owner: string; repo: string } {
  if (typeof owner !== 'string' || typeof repo !== 'string') {
    throw new Error('Repository owner and name are required.');
  }
  const cleanOwner = owner.trim();
  const cleanRepo = repo.trim();
  if (!SAFE_SEGMENT.test(cleanOwner) || !SAFE_SEGMENT.test(cleanRepo)) {
    throw new Error('Invalid repository owner or name format.');
  }
  return { owner: cleanOwner, repo: cleanRepo };
}

function getGithubToken(req: express.Request): string {
  const headerToken = req.headers['x-github-token'];
  const bodyToken = typeof req.body?.token === 'string' ? req.body.token : '';
  const token = (typeof headerToken === 'string' ? headerToken : bodyToken).trim();
  if (!token) {
    throw new Error('GitHub Personal Access Token is required in Vault Settings.');
  }
  return token;
}

async function githubFetch(url: string, token: string, init: RequestInit = {}) {
  const headers = new Headers(init.headers);
  headers.set('Authorization', `Bearer ${token}`);
  headers.set('Accept', 'application/vnd.github+json');
  headers.set('X-GitHub-Api-Version', '2022-11-28');
  headers.set('User-Agent', 'Shakya-AI-Studio');
  if (init.body && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json');
  }
  return fetch(url, { ...init, headers });
}

function bumpGradleVersion(gradleContent: string): {
  updatedContent: string;
  versionCode: number;
  versionName: string;
} {
  const codeRegex = /versionCode\s*=\s*(\d+)/;
  const nameRegex = /versionName\s*=\s*"([^"]+)"/;

  const codeMatch = gradleContent.match(codeRegex);
  const nameMatch = gradleContent.match(nameRegex);

  const oldCode = codeMatch ? parseInt(codeMatch[1], 10) : 1;
  const nextCode = oldCode + 1;

  const oldName = nameMatch ? nameMatch[1] : '1.0.0';
  const parts = oldName.split('.');
  if (parts.length >= 3) {
    const patch = parseInt(parts[2], 10);
    parts[2] = Number.isFinite(patch) ? String(patch + 1) : '1';
  } else {
    parts.push('1');
  }
  const nextName = parts.join('.');

  let updated = gradleContent;
  if (codeMatch) {
    updated = updated.replace(codeRegex, `versionCode = ${nextCode}`);
  }
  if (nameMatch) {
    updated = updated.replace(nameRegex, `versionName = "${nextName}"`);
  }

  return { updatedContent: updated, versionCode: nextCode, versionName: nextName };
}

async function commitFilesAtomically(params: {
  owner: string;
  repo: string;
  token: string;
  files: Array<{ path: string; content: string }>;
  commitMessage: string;
}): Promise<{ commitSha: string; branch: string }> {
  const { owner, repo, token, files, commitMessage } = params;
  const baseApi = `https://api.github.com/repos/${owner}/${repo}`;

  // Detect default branch (main or master)
  let branch = 'main';
  let refRes = await githubFetch(`${baseApi}/git/ref/heads/main`, token);
  if (refRes.status === 404) {
    const masterRes = await githubFetch(`${baseApi}/git/ref/heads/master`, token);
    if (masterRes.ok) {
      branch = 'master';
      refRes = masterRes;
    }
  }

  if (!refRes.ok) {
    // Repo might be brand new & empty; bootstrap via Contents API for first file
    const firstFile = files[0];
    const putFirst = await githubFetch(`${baseApi}/contents/${firstFile.path}`, token, {
      method: 'PUT',
      body: JSON.stringify({
        message: 'chore: initialize Android repository via Shakya AI Studio',
        content: Buffer.from(firstFile.content, 'utf8').toString('base64'),
      }),
    });
    if (!putFirst.ok) {
      const errText = await putFirst.text();
      throw new Error(`Failed to initialize repository branch: ${putFirst.status} ${errText}`);
    }
    refRes = await githubFetch(`${baseApi}/git/ref/heads/main`, token);
    if (!refRes.ok) {
      throw new Error('Could not resolve main branch after initialization.');
    }
  }

  const refData = (await refRes.json()) as { object: { sha: string } };
  const latestCommitSha = refData.object.sha;

  const commitRes = await githubFetch(`${baseApi}/git/commits/${latestCommitSha}`, token);
  if (!commitRes.ok) {
    throw new Error('Failed to fetch base commit on GitHub.');
  }
  const commitData = (await commitRes.json()) as { tree: { sha: string } };
  const baseTreeSha = commitData.tree.sha;

  // Create blobs in batches of 5 to avoid rate-limit bursts
  const treeItems: Array<{ path: string; mode: string; type: string; sha: string }> = [];
  for (let i = 0; i < files.length; i += 5) {
    const batch = files.slice(i, i + 5);
    const created = await Promise.all(
      batch.map(async (file) => {
        const blobRes = await githubFetch(`${baseApi}/git/blobs`, token, {
          method: 'POST',
          body: JSON.stringify({
            content: file.content,
            encoding: 'utf-8',
          }),
        });
        if (!blobRes.ok) {
          const errText = await blobRes.text();
          throw new Error(`Failed creating blob for ${file.path}: ${errText}`);
        }
        const blobData = (await blobRes.json()) as { sha: string };
        return {
          path: file.path.replace(/^\/+/, ''),
          mode: '100644',
          type: 'blob',
          sha: blobData.sha,
        };
      })
    );
    treeItems.push(...created);
  }

  const treeRes = await githubFetch(`${baseApi}/git/trees`, token, {
    method: 'POST',
    body: JSON.stringify({
      base_tree: baseTreeSha,
      tree: treeItems,
    }),
  });
  if (!treeRes.ok) {
    const errText = await treeRes.text();
    throw new Error(`Failed creating Git tree: ${errText}`);
  }
  const treeData = (await treeRes.json()) as { sha: string };

  const newCommitRes = await githubFetch(`${baseApi}/git/commits`, token, {
    method: 'POST',
    body: JSON.stringify({
      message: commitMessage,
      tree: treeData.sha,
      parents: [latestCommitSha],
    }),
  });
  if (!newCommitRes.ok) {
    const errText = await newCommitRes.text();
    throw new Error(`Failed creating Git commit: ${errText}`);
  }
  const newCommitData = (await newCommitRes.json()) as { sha: string };

  const updateRefRes = await githubFetch(`${baseApi}/git/refs/heads/${branch}`, token, {
    method: 'PATCH',
    body: JSON.stringify({
      sha: newCommitData.sha,
      force: false,
    }),
  });
  if (!updateRefRes.ok) {
    const errText = await updateRefRes.text();
    throw new Error(`Failed updating branch ${branch}: ${errText}`);
  }

  return { commitSha: newCommitData.sha, branch };
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '10mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', service: 'Shakya AI Studio' });
  });

  // 1. Gemini AI Android Builder Endpoint (BYOK: requires user's personal Gemini API Key)
  app.post('/api/gemini/build-android', async (req, res) => {
    try {
      const headerKey = req.headers['x-gemini-api-key'];
      const apiKey = typeof headerKey === 'string' ? headerKey.trim() : '';
      if (!apiKey) {
        res.status(400).json({
          error: 'Please add your personal Gemini API Key in Settings before generating code.',
        });
        return;
      }

      const { prompt, appMeta, currentPreview, mainActivityCode, language } = req.body as {
        prompt?: string;
        appMeta?: {
          name: string;
          packageName: string;
          versionName: string;
          versionCode: number;
        };
        currentPreview?: unknown;
        mainActivityCode?: string;
        language?: 'en' | 'hi';
      };

      if (!prompt || typeof prompt !== 'string' || !prompt.trim()) {
        res.status(400).json({ error: 'Prompt is required.' });
        return;
      }

      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });

      const systemInstruction = `You are the senior Android Kotlin & Jetpack Compose architect inside Shakya AI Studio ("from SHAKYA").
Your job is to take the user's request (in English or Hindi) and update BOTH:
1. The interactive Live Mobile Preview specification (ComposePreviewSpec JSON) with clean Royal Blue (#1877F2) and Pure White (#FFFFFF) Material 3 styling, bilingual English & Hindi labels, and interactive components.
2. Production-ready Kotlin Jetpack Compose source code for MainActivity.kt matching the requested feature.

Design Rules:
- Always preserve valid Kotlin syntax and Material 3 Compose imports.
- Every preview component must have both titleEn and titleHi so the user can toggle English & Hindi live in the phone preview.
- Keep "from SHAKYA" branding cleanly enabled via showFromShakyaFooter: true.
- Reply concisely in ${language === 'hi' ? 'Hindi (Devanagari) with clear technical terms' : 'English'}.`;

      const userPayload = JSON.stringify({
        userRequest: prompt.trim(),
        appMeta: appMeta ?? {
          name: 'Shakya App',
          packageName: 'com.shakya.app',
          versionName: '1.0.0',
          versionCode: 1,
        },
        currentPreview,
        existingMainActivitySnippet: (mainActivityCode ?? '').slice(0, 6000),
      });

      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: userPayload,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              reply: {
                type: Type.STRING,
                description: 'Concise summary of the Android UI & Kotlin changes made.',
              },
              updatedPreviewSpec: {
                type: Type.OBJECT,
                properties: {
                  appTitleEn: { type: Type.STRING },
                  appTitleHi: { type: Type.STRING },
                  primaryColor: { type: Type.STRING },
                  showFromShakyaFooter: { type: Type.BOOLEAN },
                  fabLabelEn: { type: Type.STRING },
                  fabLabelHi: { type: Type.STRING },
                  tabs: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        id: { type: Type.STRING },
                        labelEn: { type: Type.STRING },
                        labelHi: { type: Type.STRING },
                        icon: { type: Type.STRING },
                        components: {
                          type: Type.ARRAY,
                          items: {
                            type: Type.OBJECT,
                            properties: {
                              id: { type: Type.STRING },
                              type: { type: Type.STRING },
                              titleEn: { type: Type.STRING },
                              titleHi: { type: Type.STRING },
                              subtitleEn: { type: Type.STRING },
                              subtitleHi: { type: Type.STRING },
                              value: { type: Type.STRING },
                              actionType: { type: Type.STRING },
                              accent: { type: Type.STRING },
                            },
                            required: ['id', 'type', 'titleEn', 'titleHi'],
                          },
                        },
                      },
                      required: ['id', 'labelEn', 'labelHi', 'icon', 'components'],
                    },
                  },
                },
                required: ['appTitleEn', 'appTitleHi', 'primaryColor', 'showFromShakyaFooter', 'tabs'],
              },
              mainActivityKotlin: {
                type: Type.STRING,
                description: 'Complete updated Kotlin Jetpack Compose MainActivity.kt source code.',
              },
            },
            required: ['reply', 'updatedPreviewSpec', 'mainActivityKotlin'],
          },
        },
      });

      const rawText = response.text;
      if (!rawText) {
        throw new Error('Gemini returned an empty response.');
      }
      const parsed = JSON.parse(rawText);
      res.json(parsed);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Failed to generate Android update.';
      res.status(500).json({ error: message });
    }
  });

  // 2. Verify GitHub PAT
  app.post('/api/github/verify', async (req, res) => {
    try {
      const token = getGithubToken(req);
      const ghRes = await githubFetch('https://api.github.com/user', token);
      if (!ghRes.ok) {
        const err = await ghRes.text();
        res.status(ghRes.status).json({ error: `GitHub auth failed: ${err}` });
        return;
      }
      const user = await ghRes.json();
      res.json({ user });
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : 'Verification failed.' });
    }
  });

  // 3. List User GitHub Repositories
  app.post('/api/github/repos', async (req, res) => {
    try {
      const token = getGithubToken(req);
      const ghRes = await githubFetch('https://api.github.com/user/repos?sort=updated&per_page=30', token);
      if (!ghRes.ok) {
        const err = await ghRes.text();
        res.status(ghRes.status).json({ error: `Failed to fetch repositories: ${err}` });
        return;
      }
      const repos = await ghRes.json();
      res.json({ repos });
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : 'Failed to list repos.' });
    }
  });

  // 4. Create Repo (if needed) & Push Full Android Project Atomically
  app.post('/api/github/create-and-push', async (req, res) => {
    try {
      const token = getGithubToken(req);
      const { owner, repo } = validateRepoOwnerAndName(req.body?.owner, req.body?.repo);
      const description = typeof req.body?.description === 'string' ? req.body.description : 'Built with Shakya AI Studio';
      const files = req.body?.files as Array<{ path: string; content: string }> | undefined;

      if (!Array.isArray(files) || files.length === 0) {
        res.status(400).json({ error: 'Project files array is required.' });
        return;
      }

      // Check if repository already exists
      const checkRes = await githubFetch(`https://api.github.com/repos/${owner}/${repo}`, token);
      if (checkRes.status === 404) {
        const createRes = await githubFetch('https://api.github.com/user/repos', token, {
          method: 'POST',
          body: JSON.stringify({
            name: repo,
            description,
            private: false,
            auto_init: true,
          }),
        });
        if (!createRes.ok) {
          const errText = await createRes.text();
          res.status(createRes.status).json({ error: `Could not create repo: ${errText}` });
          return;
        }
        // Wait briefly for GitHub to finalize auto_init branch ref
        await new Promise((resolve) => setTimeout(resolve, 1200));
      } else if (!checkRes.ok) {
        const errText = await checkRes.text();
        res.status(checkRes.status).json({ error: `GitHub repo lookup failed: ${errText}` });
        return;
      }

      const result = await commitFilesAtomically({
        owner,
        repo,
        token,
        files,
        commitMessage: 'feat: initialize Android Compose project & APK/AAB CI workflow via Shakya AI Studio',
      });

      res.json({
        success: true,
        commitSha: result.commitSha,
        branch: result.branch,
        repoUrl: `https://github.com/${owner}/${repo}`,
      });
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : 'Failed to push project to GitHub.' });
    }
  });

  // 5. Auto-Update Existing App: Fetch app/build.gradle.kts, Bump versionCode (+1) & versionName, Commit
  app.post('/api/github/update-and-bump', async (req, res) => {
    try {
      const token = getGithubToken(req);
      const { owner, repo } = validateRepoOwnerAndName(req.body?.owner, req.body?.repo);
      const files = req.body?.files as Array<{ path: string; content: string }> | undefined;
      const commitSummary = typeof req.body?.commitMessage === 'string' && req.body.commitMessage.trim()
        ? req.body.commitMessage.trim()
        : 'feat: AI Workspace update via Shakya AI Studio';

      if (!Array.isArray(files) || files.length === 0) {
        res.status(400).json({ error: 'Updated files are required.' });
        return;
      }

      // Fetch live app/build.gradle.kts from GitHub if present so we always increment from the true remote versionCode
      let remoteGradleContent: string | null = null;
      const gradleRes = await githubFetch(`https://api.github.com/repos/${owner}/${repo}/contents/app/build.gradle.kts`, token);
      if (gradleRes.ok) {
        const gradleJson = (await gradleRes.json()) as { content?: string };
        if (gradleJson.content) {
          remoteGradleContent = Buffer.from(gradleJson.content, 'base64').toString('utf8');
        }
      }

      const localGradleFile = files.find((f) => f.path === 'app/build.gradle.kts');
      const sourceGradle = remoteGradleContent ?? localGradleFile?.content;
      if (!sourceGradle) {
        res.status(400).json({ error: 'app/build.gradle.kts not found in repository or payload.' });
        return;
      }

      const bumped = bumpGradleVersion(sourceGradle);
      const mergedFiles = files.map((f) =>
        f.path === 'app/build.gradle.kts' ? { ...f, content: bumped.updatedContent } : f
      );
      if (!mergedFiles.some((f) => f.path === 'app/build.gradle.kts')) {
        mergedFiles.push({ path: 'app/build.gradle.kts', content: bumped.updatedContent });
      }

      const commitResult = await commitFilesAtomically({
        owner,
        repo,
        token,
        files: mergedFiles,
        commitMessage: `${commitSummary} (v${bumped.versionName} / Build ${bumped.versionCode})`,
      });

      res.json({
        success: true,
        commitSha: commitResult.commitSha,
        branch: commitResult.branch,
        versionCode: bumped.versionCode,
        versionName: bumped.versionName,
        updatedGradleContent: bumped.updatedContent,
      });
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : 'Auto-update failed.' });
    }
  });

  // 6. Poll GitHub Actions Workflow Runs & Artifacts
  app.post('/api/github/runs', async (req, res) => {
    try {
      const token = getGithubToken(req);
      const { owner, repo } = validateRepoOwnerAndName(req.body?.owner, req.body?.repo);

      const runsRes = await githubFetch(
        `https://api.github.com/repos/${owner}/${repo}/actions/runs?per_page=5`,
        token
      );
      if (!runsRes.ok) {
        const errText = await runsRes.text();
        res.status(runsRes.status).json({ error: `Could not fetch workflow runs: ${errText}` });
        return;
      }

      const runsJson = (await runsRes.json()) as {
        workflow_runs: Array<{
          id: number;
          name: string;
          status: string;
          conclusion: string | null;
          head_sha: string;
          head_commit?: { message?: string };
          created_at: string;
          updated_at: string;
          html_url: string;
          run_number: number;
        }>;
      };

      const runs = runsJson.workflow_runs ?? [];
      let latestSteps: Array<{ name: string; status: string; conclusion: string | null; number: number }> = [];
      let artifacts: Array<{
        id: number;
        name: string;
        size_in_bytes: number;
        archive_download_url: string;
        expired: boolean;
        created_at: string;
        kind: 'apk' | 'aab' | 'other';
      }> = [];

      if (runs.length > 0) {
        const latestRun = runs[0];
        const [jobsRes, artifactsRes] = await Promise.all([
          githubFetch(`https://api.github.com/repos/${owner}/${repo}/actions/runs/${latestRun.id}/jobs`, token),
          githubFetch(`https://api.github.com/repos/${owner}/${repo}/actions/runs/${latestRun.id}/artifacts`, token),
        ]);

        if (jobsRes.ok) {
          const jobsData = (await jobsRes.json()) as {
            jobs?: Array<{ steps?: Array<{ name: string; status: string; conclusion: string | null; number: number }> }>;
          };
          latestSteps = jobsData.jobs?.[0]?.steps ?? [];
        }

        if (artifactsRes.ok) {
          const artData = (await artifactsRes.json()) as {
            artifacts?: Array<{
              id: number;
              name: string;
              size_in_bytes: number;
              archive_download_url: string;
              expired: boolean;
              created_at: string;
            }>;
          };
          artifacts = (artData.artifacts ?? []).map((a) => ({
            ...a,
            kind: a.name.toLowerCase().includes('apk')
              ? 'apk'
              : a.name.toLowerCase().includes('aab')
                ? 'aab'
                : 'other',
          }));
        }
      }

      res.json({ runs, latestSteps, artifacts });
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : 'Failed to poll workflow runs.' });
    }
  });

  // 7. Download & Unpack APK or AAB Artifact from GitHub Actions
  app.post('/api/github/download-artifact', async (req, res) => {
    try {
      const token = getGithubToken(req);
      const { owner, repo } = validateRepoOwnerAndName(req.body?.owner, req.body?.repo);
      const artifactId = Number(req.body?.artifactId);
      const targetExt = req.body?.targetExt === 'aab' ? '.aab' : '.apk';

      if (!Number.isFinite(artifactId) || artifactId <= 0) {
        res.status(400).json({ error: 'Valid artifactId is required.' });
        return;
      }

      const zipRes = await githubFetch(
        `https://api.github.com/repos/${owner}/${repo}/actions/artifacts/${artifactId}/zip`,
        token
      );
      if (!zipRes.ok) {
        const errText = await zipRes.text();
        res.status(zipRes.status).json({ error: `Artifact download failed: ${errText}` });
        return;
      }

      const arrayBuffer = await zipRes.arrayBuffer();
      const zip = await JSZip.loadAsync(arrayBuffer);
      const matchingEntry = Object.values(zip.files).find(
        (entry) => !entry.dir && entry.name.toLowerCase().endsWith(targetExt)
      );

      if (matchingEntry) {
        const fileBuffer = await matchingEntry.async('nodebuffer');
        const fileName = path.basename(matchingEntry.name);
        const mimeType =
          targetExt === '.apk' ? 'application/vnd.android.package-archive' : 'application/octet-stream';
        res.setHeader('Content-Type', mimeType);
        res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
        res.send(fileBuffer);
        return;
      }

      // Fallback: stream the ZIP archive if nested structure differs
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', `attachment; filename="${repo}-${targetExt.slice(1)}.zip"`);
      res.send(Buffer.from(arrayBuffer));
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : 'Failed to download artifact.' });
    }
  });

  // Vite dev middleware or static production files
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Shakya AI Studio server listening on http://localhost:${PORT}`);
  });
}

startServer();

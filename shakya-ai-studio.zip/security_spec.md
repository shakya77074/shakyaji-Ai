# Security Specification — Shakya AI Studio

## 1. Data Invariants
1. Every `UserProfile` document at `/users/{userId}` can only be read or written by the authenticated verified user whose `request.auth.uid == userId`.
2. Every `SavedApp` document at `/users/{userId}/apps/{appId}` belongs strictly to `ownerId == userId == request.auth.uid`.
3. `ownerId` and `createdAt` are immutable after creation; timestamps (`createdAt`, `updatedAt`) must match `request.time`.
4. All IDs (`userId`, `appId`) must satisfy `isValidId()` (`<= 128` chars, `^[a-zA-Z0-9_\-]+$`).
5. Package names must match Android reverse-DNS syntax (`^[a-z][a-z0-9_]*(\.[a-z0-9_]+)+$`).

## 2. Adversarial Payloads Tested ("Dirty Dozen")
1. Unauthenticated read on `/users/u1` -> DENIED
2. Cross-user read on `/users/u2/apps/app1` by `u1` -> DENIED
3. Unverified email write on `/users/u1/apps/app1` -> DENIED
4. Shadow field injection (`isAdmin: true`) on `UserProfile` create -> DENIED (`hasOnly`)
5. Spoofed `ownerId: "victim"` on `SavedApp` create -> DENIED (`ownerId == request.auth.uid`)
6. Oversized `appId` (>128 chars or special chars) -> DENIED (`isValidId`)
7. Invalid `packageName` (`"Invalid Package!"`) -> DENIED (regex check)
8. Negative `versionCode: -5` -> DENIED (`versionCode >= 1`)
9. Client-forged `createdAt` timestamp -> DENIED (`createdAt == request.time`)
10. Mutating immutable `ownerId` or `createdAt` on update -> DENIED
11. Unbounded `mainActivityKotlin` (>60,000 chars) -> DENIED
12. Unscoped collection `list` without owner check -> DENIED
